"""
score_e7.py - score every saved E7 run against the true graph (inputs of Table 6).

    python score_e7.py --data data/E7 --results results/E7_lambda5          (any Python with numpy + pandas)

Reads   results/E7_lambda5/<variant>_<method>/<dataset_folder>/posterior_samples.npy  (100, D, D), adj[j, i] = 1: j -> i
        results/E7_lambda5/<variant>_<method>/<dataset_folder>/training_log.json
        <variant> in {deci_g, deci_s}; <method> = baseline now, e.g. graphaware later (same scorer, same tables).
Writes  results/E7_lambda5/e7_per_run.csv   one row per (variant, method, regime, missing rate, seed) found on disk

KPIs: expected SHD / adjacency F1 / orientation F1 over the 100 posterior graphs (same definitions as E1/E2),
cyclic-sample rate, posterior mass on the true graph, runtime, and the imputation quality columns written by
train_deci_missing.py (impute_rmse, impute_rmse_mean_fill, impute_nll, in z-score units; empty for complete data).
A run folder without posterior_samples.npy is recorded as "missing" or "failed", never dropped silently.
"""
import argparse
import glob
import json
import os

import numpy as np
import pandas as pd

from metrics import expected_metrics

LOG_KEYS = ("converged", "final_acyclicity_penalty", "final_elbo", "steps", "outer_rounds", "runtime_s",
            "prior_sparsity_lambda", "impute_rmse", "impute_rmse_mean_fill", "impute_nll", "n_missing", "imputer")


def score_run(folder: str, run_dir: str, variant: str, method: str) -> dict:
    cfg = json.load(open(os.path.join(folder, "config.json")))
    true = np.loadtxt(os.path.join(folder, "adj_matrix.csv"), delimiter=",", ndmin=2).astype(int)
    d = int(cfg["d"])
    row = dict(variant=variant, method=method, regime=cfg.get("regime"), missing_rate=int(cfg.get("missing_rate", 0)),
               D=d, n_train=int(cfg["n_train"]), seed=int(cfg["seed"]), folder=os.path.basename(folder))
    sample_path = os.path.join(run_dir, "posterior_samples.npy")
    if not os.path.exists(sample_path):
        err = os.path.join(run_dir, "error.txt")
        row.update(status="failed" if os.path.exists(err) else "missing",
                   error=open(err).read().strip() if os.path.exists(err) else "no posterior_samples.npy")
        return row
    try:
        samples = (np.load(sample_path) > 0.5).astype(int)
        if samples.ndim != 3 or samples.shape[1:] != (d, d):
            raise ValueError(f"bad shape {samples.shape}, expected (S, {d}, {d})")
        m = expected_metrics(samples, true)
        row.update(expected_shd=m["expected_shd"], expected_adj_f1=m["expected_adj_f1"],
                   expected_orient_f1=m["expected_orient_f1"], posterior_mass_g0=m["posterior_mass_g0"],
                   cyclic_rate=m["cyclic_rate"], mean_edges=float(samples.sum(axis=(1, 2)).mean()),
                   status="ok", error="")
        log_path = os.path.join(run_dir, "training_log.json")
        if os.path.exists(log_path):
            log = json.load(open(log_path))
            for k in LOG_KEYS:
                row[k] = log.get(k)
            if log.get("runtime_s") is not None:
                row["runtime_h"] = float(log["runtime_s"]) / 3600.0
    except Exception as exc:
        row.update(status="failed", error=f"{type(exc).__name__}: {exc}")
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/E7")
    parser.add_argument("--results", default="results/E7_lambda5")
    args = parser.parse_args()
    rows = []
    for method_dir in sorted(glob.glob(os.path.join(args.results, "deci_*_*"))):
        tag = os.path.basename(method_dir)                       # e.g. deci_g_baseline
        variant, method = tag.rsplit("_", 1)[0], tag.rsplit("_", 1)[1]
        for run_dir in sorted(glob.glob(os.path.join(method_dir, "*"))):
            name = os.path.basename(run_dir)
            folder = os.path.join(args.data, name)
            if not os.path.exists(os.path.join(folder, "config.json")):
                print(f"skipping {tag}/{name}: no dataset folder {folder}")
                continue
            rows.append(score_run(folder, run_dir, variant, method))
    if not rows:
        raise SystemExit(f"no runs found under {args.results}/deci_*_*")
    df = pd.DataFrame(rows).sort_values(["variant", "method", "regime", "missing_rate", "seed"]).reset_index(drop=True)
    out = os.path.join(args.results, "e7_per_run.csv")
    df.to_csv(out, index=False)
    print(df.groupby(["variant", "method", "status"]).size().to_string())
    show = [c for c in ("variant", "method", "regime", "missing_rate", "seed", "expected_shd", "expected_adj_f1",
                        "expected_orient_f1", "impute_rmse", "impute_rmse_mean_fill", "converged", "runtime_h")
            if c in df.columns]
    print(df[show].round(3).to_string(index=False))
    print(f"-> {out}")


if __name__ == "__main__":
    main()
