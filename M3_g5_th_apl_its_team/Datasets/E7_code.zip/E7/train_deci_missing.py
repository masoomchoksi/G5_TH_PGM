"""
train_deci_missing.py - E7 BASELINE: train DECI-G / DECI-S with the paper's amortised imputation on the
E7 datasets (Causica 0.4.6). Same command line, outputs and conventions as train_deci.py (E1/E2).

    results/E7_lambda5/<variant>_baseline/<dataset_folder>/posterior_samples.npy   (100, d, d), adj[j, i] = 1: j -> i
    results/E7_lambda5/<variant>_baseline/<dataset_folder>/training_log.json

* Datasets WITHOUT missing cells (miss0) are trained with train_deci.train_one, i.e. exactly the E1/E2 code path:
  the paper's model uses no imputer when nothing is missing. For the nonlinear regime, seeds 0-2 these runs
  reproduce the E1 / E2 DECI runs (same data, seed and settings), which is the sanity check P-5.
* Datasets WITH missing cells use deci_missing.DECIModuleMissing (imputer + reconstruction regulariser).
* All other settings are those of train_deci.py (Causica 0.4.6 defaults, lambda_s via --sparsity-lambda 5).

Environment: Python 3.10, pip install causica==0.4.6 pandas numpy     (same as E1/E2)

Smoke test (one run, 30 % missing; then check the convention and the SHD):
    python train_deci_missing.py --variant deci_g --data data/E7 --results results/E7_lambda5 \
        --sparsity-lambda 5 --progress --only er16_16_n1000_nonlinear_seed0_miss30
"""

import torch  # noqa: F401  MUST stay first (see train_deci.py)
import os
os.environ["MPLBACKEND"] = "Agg"
import argparse
import glob
import json
import time
import traceback

import numpy as np
import pandas as pd

from train_deci import metric_value, train_one


def has_missing(folder: str) -> bool:
    return bool(pd.read_csv(os.path.join(folder, "train.csv")).isna().values.any())


def train_one_missing(folder, variant, out_dir, batch_size, max_steps, sparsity_lambda, imputer_lr,
                      max_p_dropout, recon_factor, n_samples=100, progress=False):
    import pytorch_lightning as pl
    from causica.datasets.causica_dataset_format import Variable
    from causica.datasets.variable_types import VariableTypeEnum
    from causica.distributions.noise.joint import ContinuousNoiseDist

    from deci_missing import DECIModuleMissing, MissingDECIDataModule

    cfg = json.load(open(os.path.join(folder, "config.json")))
    df = pd.read_csv(os.path.join(folder, "train.csv"))
    full = pd.read_csv(os.path.join(folder, "train_full.csv"))
    seed = int(cfg["seed"])
    pl.seed_everything(seed, workers=True)

    variables = [Variable(group_name=c, name=c, type=VariableTypeEnum.CONTINUOUS) for c in df.columns]
    datamodule = MissingDECIDataModule(df, variables, batch_size=min(batch_size, len(df)),
                                       dataset_name=os.path.basename(folder))
    kwargs = dict(noise_dist=ContinuousNoiseDist.SPLINE if variant == "deci_s" else ContinuousNoiseDist.GAUSSIAN,
                  imputer_lr=imputer_lr, max_p_train_dropout=max_p_dropout, reconstruction_loss_factor=recon_factor)
    if sparsity_lambda is not None:
        kwargs["prior_sparsity_lambda"] = sparsity_lambda
    module = DECIModuleMissing(**kwargs)

    trainer = pl.Trainer(max_epochs=-1, max_steps=max_steps, accelerator="auto", devices=1,
                         logger=False, enable_checkpointing=False,
                         enable_progress_bar=progress, enable_model_summary=False)
    start = time.time()
    trainer.fit(module, datamodule=datamodule)
    runtime = time.time() - start

    module.eval()
    with torch.no_grad():
        sems = module.sem_module().sample(torch.Size([n_samples]))
        graphs = torch.stack([sem.graph for sem in sems]).cpu().numpy()
    graphs = (graphs > 0.5).astype(np.int8)

    # imputation quality on the missing training entries (z-score units of the observed-entry statistics)
    z = np.where(datamodule.obs_mask > 0,
                 (df.to_numpy() - datamodule.col_mean) / datamodule.col_std, 0.0)
    z_true = (full.to_numpy() - datamodule.col_mean) / datamodule.col_std
    impute = module.imputation_report(np.nan_to_num(z), datamodule.obs_mask, z_true)

    metrics = {k: v.item() if hasattr(v, "item") else v for k, v in trainer.callback_metrics.items()}
    n = len(df)
    blp = metric_value(metrics, "batch_log_prob")
    ent = metric_value(metrics, "vardist_entropy")
    pri = metric_value(metrics, "prior_term")
    imp_ent = metric_value(metrics, "imputation_entropy")
    elbo = None
    if None not in (blp, ent, pri, imp_ent):
        elbo = blp + imp_ent + (ent + pri) / n               # ELBO / N including the imputation entropy
    hit_cap = max_steps is not None and max_steps > 0 and trainer.global_step >= max_steps
    log = dict(
        variant=variant, method="baseline", dataset=os.path.basename(folder), seed=seed, n_train=n,
        missing_rate=cfg.get("missing_rate"), regime=cfg.get("regime"),
        final_elbo=elbo, final_acyclicity_penalty=metric_value(metrics, "constraint"),
        outer_rounds=int(module.lr_scheduler.outer_opt_counter),
        converged=bool(trainer.should_stop and not hit_cap),
        steps=int(trainer.global_step), runtime_s=round(runtime, 1),
        batch_size=min(batch_size, n), prior_sparsity_lambda=module.prior_sparsity_lambda,
        imputer="graph_agnostic_amortised_gaussian", imputer_lr=imputer_lr,
        max_p_train_dropout=max_p_dropout, reconstruction_loss_factor=recon_factor,
        reconstruction_err=metric_value(metrics, "reconstruction_err"),
        mean_edges_in_samples=float(graphs.sum(axis=(1, 2)).mean()),
        causica_version="0.4.6", torch_version=torch.__version__, **impute,
    )
    os.makedirs(out_dir, exist_ok=True)
    np.save(os.path.join(out_dir, "posterior_samples.npy"), graphs)
    json.dump(log, open(os.path.join(out_dir, "training_log.json"), "w"), indent=2)
    return graphs, log


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", required=True, choices=["deci_s", "deci_g"])
    parser.add_argument("--data", default="data/E7")
    parser.add_argument("--results", default="results/E7_lambda5")
    parser.add_argument("--only", nargs="*", default=None, help="dataset folder names to run")
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--max-steps", type=int, default=400_000)
    parser.add_argument("--sparsity-lambda", type=float, default=None)
    parser.add_argument("--imputer-lr", type=float, default=1e-3, help="learning rate of the imputer (logged)")
    parser.add_argument("--max-p-dropout", type=float, default=0.6, help="v0.0.0 default 0.6")
    parser.add_argument("--recon-factor", type=float, default=1.0, help="v0.0.0 default 1.0")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--progress", action="store_true")
    args = parser.parse_args()

    from deci_interface import check_orientation_convention

    folders = sorted(glob.glob(os.path.join(args.data, "*")))
    if args.only:
        folders = [f for f in folders if os.path.basename(f) in set(args.only)]
    checked = False
    for folder in folders:
        name = os.path.basename(folder)
        out_dir = os.path.join(args.results, f"{args.variant}_baseline", name)
        if os.path.exists(os.path.join(out_dir, "posterior_samples.npy")) and not args.overwrite:
            print(f"[{args.variant}] {name}: exists, skipping")
            continue
        try:
            if has_missing(folder):
                graphs, log = train_one_missing(folder, args.variant, out_dir, args.batch_size, args.max_steps,
                                                args.sparsity_lambda, args.imputer_lr, args.max_p_dropout,
                                                args.recon_factor, progress=args.progress)
            else:                                                     # complete data: the E1/E2 code path
                graphs, log = train_one(folder, args.variant, out_dir, args.batch_size, args.max_steps,
                                        args.sparsity_lambda, progress=args.progress)
                cfg = json.load(open(os.path.join(folder, "config.json")))
                log.update(method="baseline", imputer="none (complete data)", missing_rate=cfg.get("missing_rate"),
                           regime=cfg.get("regime"))
                json.dump(log, open(os.path.join(out_dir, "training_log.json"), "w"), indent=2)
            print(f"[{args.variant}] {name}: converged={log['converged']} steps={log['steps']} "
                  f"edges~{log['mean_edges_in_samples']:.1f} ({log['runtime_s']}s)"
                  + (f" impute_rmse={log['impute_rmse']:.3f} (mean-fill {log['impute_rmse_mean_fill']:.3f})"
                     if log.get("impute_rmse") is not None else ""))
            if not checked:
                true = np.loadtxt(os.path.join(folder, "adj_matrix.csv"), delimiter=",", ndmin=2).astype(int)
                print("  convention check:", check_orientation_convention(graphs, true))
                checked = True
        except Exception as exc:
            traceback.print_exc()
            os.makedirs(out_dir, exist_ok=True)
            with open(os.path.join(out_dir, "error.txt"), "w") as f:
                f.write(f"{type(exc).__name__}: {exc}\n")
            print(f"[{args.variant}] {name}: FAILED ({type(exc).__name__})")


if __name__ == "__main__":
    main()
