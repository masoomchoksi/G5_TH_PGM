"""
make_e7_data.py - build the frozen E7 datasets (missing values, MCAR) from the E1/E2 generator.

For every (regime, seed) one complete dataset is generated with the SAME code as E1/E2
(data_generation.make_nested_datasets, n_pool = 5000, train set = first n rows, n_test = 2000).
Consequence: regime "nonlinear" (non-linear ANM, warped noise) at n = 1000, seeds 0-2 is
byte-for-byte the E1 / E2 dataset er16_16_n1000_seed{0,1,2}. Regime "lingauss" is the linear
Gaussian SEM (same DAG sampler; the mechanisms and noise differ).

Missing values: MCAR, every entry of the training matrix is removed independently with
probability rate/100. The test set is never masked. One folder per (regime, seed, rate):

    data/E7/er16_16_n1000_<regime>_seed<s>_miss<rate>/
        train.csv        training data, missing entries are EMPTY cells (read as NaN)
        train_full.csv   the complete training data (only used to score imputation quality)
        test.csv, adj_matrix.csv, config.json

Rate 0 is the complete dataset (train.csv has no empty cells).

    python make_e7_data.py --out data                      # default grid (24 folders)
    python make_e7_data.py --out data --validate-only
"""
import argparse
import json
import os

import numpy as np
import pandas as pd

from data_generation import make_nested_datasets

REGIMES = {                                   # name -> (mechanism, noise)
    "nonlinear": ("nonlinear", "warped"),     # the E1 / E2 family
    "lingauss": ("linear", "gaussian"),       # the true conditional of a missing entry is Gaussian
}
DEFAULT_REGIMES = ["nonlinear", "lingauss"]
DEFAULT_RATES = [0, 10, 30, 50]
DEFAULT_SEEDS = [0, 1, 2]


def mcar_mask(n: int, d: int, rate: int, seed: int):
    """Boolean matrix, True = entry is MISSING. Every row keeps at least one observed entry."""
    if rate == 0:
        return np.zeros((n, d), dtype=bool), 0
    rng = np.random.default_rng(1_000_003 * seed + 101 * rate + 7)
    miss = rng.random((n, d)) < rate / 100.0
    all_missing = np.where(miss.all(axis=1))[0]
    for r in all_missing:                      # practically never happens for d = 16
        miss[r, rng.integers(d)] = False
    return miss, int(len(all_missing))


def folder_name(d, e, n, regime, seed, rate):
    return f"er{d}_{e}_n{n}_{regime}_seed{seed}_miss{rate}"


def generate(out_root, regimes, rates, seeds, d=16, n=1000, overwrite=False):
    folders = []
    for regime in regimes:
        mech, noise = REGIMES[regime]
        for seed in seeds:
            sem, subsets, X_test = make_nested_datasets(
                [n], n_pool=5000, d=d, n_edges=d, graph="er", mechanism=mech, noise=noise,
                n_test=2000, seed=seed)
            X = subsets[n]
            cols = [f"x{i}" for i in range(d)]
            for rate in rates:
                folder = os.path.join(out_root, "E7", folder_name(d, d, n, regime, seed, rate))
                folders.append(folder)
                if os.path.exists(os.path.join(folder, "config.json")) and not overwrite:
                    continue
                os.makedirs(folder, exist_ok=True)
                miss, fixed = mcar_mask(n, d, rate, seed)
                Xm = X.copy()
                Xm[miss] = np.nan
                pd.DataFrame(Xm, columns=cols).to_csv(os.path.join(folder, "train.csv"), index=False)
                pd.DataFrame(X, columns=cols).to_csv(os.path.join(folder, "train_full.csv"), index=False)
                pd.DataFrame(X_test, columns=cols).to_csv(os.path.join(folder, "test.csv"), index=False)
                np.savetxt(os.path.join(folder, "adj_matrix.csv"), sem.adj, fmt="%d", delimiter=",")
                meta = dict(experiment="E7", d=d, n_edges=d, graph="er", regime=regime,
                            mechanism=mech, noise=noise, n_train=n, n_test=2000, seed=seed,
                            missing_rate=rate, missingness="MCAR",
                            realised_missing_fraction=float(miss.mean()), rows_fixed_all_missing=fixed,
                            design=("E1_dataset_plus_MCAR_mask" if regime == "nonlinear"
                                    else "lingauss_plus_MCAR_mask"))
                with open(os.path.join(folder, "config.json"), "w") as f:
                    json.dump(meta, f, indent=2)
    return folders


def validate(folders):
    ok = True
    for f in folders:
        cfg = json.load(open(os.path.join(f, "config.json")))
        tr = pd.read_csv(os.path.join(f, "train.csv"))
        full = pd.read_csv(os.path.join(f, "train_full.csv"))
        miss = tr.isna().values
        problems = []
        if tr.shape != (cfg["n_train"], cfg["d"]):
            problems.append(f"shape {tr.shape}")
        if not np.allclose(tr.values[~miss], full.values[~miss]):
            problems.append("observed entries differ from train_full.csv")
        if miss.all(axis=1).any():
            problems.append("a row is fully missing")
        if abs(miss.mean() - cfg["missing_rate"] / 100) > 0.03:
            problems.append(f"missing fraction {miss.mean():.3f} vs {cfg['missing_rate']}%")
        if cfg["missing_rate"] == 0 and miss.any():
            problems.append("rate 0 has missing cells")
        print(("OK   " if not problems else "FAIL ") + os.path.basename(f) +
              f"  missing={miss.mean():.3f}" + ("" if not problems else "  " + "; ".join(problems)))
        ok &= not problems
    return ok


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", default="data")
    p.add_argument("--regimes", nargs="+", default=DEFAULT_REGIMES, choices=list(REGIMES))
    p.add_argument("--rates", type=int, nargs="+", default=DEFAULT_RATES)
    p.add_argument("--seeds", type=int, nargs="+", default=DEFAULT_SEEDS)
    p.add_argument("--n", type=int, default=1000)
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--validate-only", action="store_true")
    a = p.parse_args()
    if a.validate_only:
        folders = [os.path.join(a.out, "E7", folder_name(16, 16, a.n, rg, s, r))
                   for rg in a.regimes for s in a.seeds for r in a.rates]
    else:
        folders = generate(a.out, a.regimes, a.rates, a.seeds, n=a.n, overwrite=a.overwrite)
    raise SystemExit(0 if validate(folders) else 1)


if __name__ == "__main__":
    main()
