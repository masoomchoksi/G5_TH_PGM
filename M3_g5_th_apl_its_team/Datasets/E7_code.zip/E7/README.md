# E7 baseline: DECI with amortised imputation on Causica 0.4.6

E7 = missing data (Table 6, prediction P5). This folder contains the **baseline**: DECI with the paper's
graph-agnostic imputation network, re-implemented inside Causica 0.4.6 (which has no imputation code of its own).
The proposed graph-aware imputer will be added later as a second *method* and scored with the same scripts.

## Files
| File | Purpose |
|---|---|
| `checksum_data.py`, `MANIFEST_E7.sha256` (in `data/E7`) | SHA-256 manifest of the frozen data; `--verify` proves every device has identical files |
| `make_e7_data.py` | Frozen E7 datasets: E1 data + MCAR masks (0/10/30/50 %), regimes `nonlinear` (E1/E2 family) and `lingauss` |
| `deci_missing.py` | Data module with an observation mask, imputer network, `DECIModuleMissing` (new `training_step`) |
| `train_deci_missing.py` | Runner (same CLI as `train_deci.py`); complete datasets use the unchanged E1/E2 code path |
| `score_e7.py`, `aggregate_e7.py` | Per-run KPIs, Table 6, plot, and the P-5 sanity check |
| `check_e7_module.py` | 30-second self-check of the module (run once before the real runs) |
| `test_imputer_math.py` | Numerical proof that the imputer's ELBO is implemented correctly (compares with the exact Gaussian posterior) |
| `metrics.py`, `data_generation.py`, `deci_interface.py`, `train_deci.py` | Unchanged copies from your E2 package |

## What is ported from the DECI paper's code (Causica v0.0.0) and what is not
Ported: MLP imputer on `[x * mask, mask]` giving an independent Gaussian per variable (log-scale clipped to [-20, 5];
hidden layers `[max(80, 2D)] * 2`, LeakyReLU, layer norm, residual where widths match); missing entries are filled with a
reparameterised sample; the ELBO gains the imputation entropy; the *reconstruction regulariser* (extra random dropout of
observed entries, up to 60 %, squared error on observed entries, factor 1.0) is kept. **The imputer never sees the graph.**
Not identical: the 0.4.6 training machinery (per-module learning rates, scheduler, batch size 512); the imputer has its
own optimiser group with learning rate `--imputer-lr` (default 1e-3; v0.0.0 used one learning rate for everything,
so this value is ours and should be reported). Only all-continuous data are supported, as in v0.0.0.
In the report call this baseline "our re-implementation of DECI's missing-data handling in Causica 0.4.6".

## Run (Colab; same environment as E2)
```
# the 24 frozen dataset folders ship in this zip (data/E7); do NOT regenerate them
python checksum_data.py --verify data/E7                # must print DATA IDENTICAL on every device
python make_e7_data.py --out data --validate-only
python train_deci_missing.py --variant deci_g --data data/E7 --results results/E7_lambda5 --sparsity-lambda 5 --progress \
    --only er16_16_n1000_nonlinear_seed0_miss30          # pilot: ONE run, note its runtime
python score_e7.py --data data/E7 --results results/E7_lambda5
python aggregate_e7.py --results results/E7_lambda5 --out results/E7_lambda5/summary \
    --ref-results results/E1_lambda5 --ref-data data/E1  # last two flags: P-5 check against your E1 runs
```
Grid: 2 regimes x 4 missing rates x 3 seeds = 24 DECI-G runs. The `nonlinear` regime at 0 % uses the exact E1 data
(`er16_16_n1000_seed{0,1,2}`) and the exact E1 code path, so those 3 runs must reproduce E1 (P-5); if they do not
(beyond the usual hardware nondeterminism) something is wrong.

## What was and was not tested
Imputer correctness (`test_imputer_math.py`, passes): with the real `training_step` and a stand-in structural model equal to a known
Gaussian density, an imputer trained on the pure ELBO reproduces the exact conditional mean (RMSE 0.017) and the mean-field-optimal
scale (0.5 % relative error); observed entries are never altered; the reconstruction term enters the loss exactly once; the ELBO
gradient (not only the reconstruction gradient) reaches the imputer; a complete batch is a no-op.
Tested (Python 3.10, Causica 0.4.6, CPU, torch 2.13): data generation and validation; byte-identity of the 0 % data with
the E1/E2 dataset; module setup, one training step, gradient flow into both the imputer and the DECI model, the extra
optimiser group and scheduler entry; three complete training runs (6 variables, 300 rows, 1500-3000 steps) through the
runner, scorer and aggregator. Not tested: GPU/Colab, the real size (16 variables, 1000 rows), convergence, or run time.
The imputer learning rate is untuned: look at `impute_rmse` against `impute_rmse_mean_fill` in the pilot; the imputer is
only doing its job if the first is clearly below the second.

## Known limitations
* MCAR only (as in the paper). * Gaussian imputation family: for nonlinear data the true conditional of a missing entry is
not Gaussian, so a gap to the exact posterior remains (this is the Part B finding, not a bug).
* The datasets carry no interventions, so there is no ATE column for E7 (same as E1/E2).
