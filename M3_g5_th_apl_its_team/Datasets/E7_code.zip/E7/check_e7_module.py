"""
check_e7_module.py - 30-second sanity check of the E7 baseline module (run it once before the real runs).

    /content/venv310/bin/python check_e7_module.py data/E7/er16_16_n1000_nonlinear_seed0_miss30

Checks: the mask and shapes reach the module, observed entries are z-scored with observed statistics and missing
entries are 0, one training step gives a finite loss, the gradient reaches BOTH the imputer and the DECI structural
model, the optimiser has the extra "imputer" group and the scheduler knows its learning rate.
"""
import torch  # noqa: F401  must stay first
import os
os.environ["MPLBACKEND"] = "Agg"
import sys

import numpy as np
import pandas as pd
import pytorch_lightning as pl
from causica.datasets.causica_dataset_format import Variable
from causica.datasets.variable_types import VariableTypeEnum
from causica.distributions.noise.joint import ContinuousNoiseDist

from deci_missing import MASK_KEY, DECIModuleMissing, MissingDECIDataModule, standardise_with_mask

folder = sys.argv[1]
df = pd.read_csv(os.path.join(folder, "train.csv"))
variables = [Variable(group_name=c, name=c, type=VariableTypeEnum.CONTINUOUS) for c in df.columns]
dm = MissingDECIDataModule(df, variables, batch_size=128)
z, mask, _, _ = standardise_with_mask(df)
obs = mask > 0
assert bool((z[~obs] == 0).all()), "missing entries must be 0 after z-scoring"
assert abs(z[:, 0][obs[:, 0]].mean()) < 1e-5 and abs(z[:, 0][obs[:, 0]].std(ddof=1) - 1) < 1e-4, "column 0 not standardised"
assert len(dm.variable_shapes) == df.shape[1], "mask must not become an extra variable"

module = DECIModuleMissing(noise_dist=ContinuousNoiseDist.GAUSSIAN, prior_sparsity_lambda=5)
pl.Trainer(max_steps=1, accelerator="cpu", logger=False, enable_checkpointing=False,
           enable_progress_bar=False, enable_model_summary=False).fit(module, datamodule=dm)
batch = next(iter(dm.train_dataloader()))
assert MASK_KEY in batch.keys() and tuple(batch[MASK_KEY].shape) == (128, df.shape[1])
module.train()
module.log_dict = lambda *a, **k: None          # logging needs a running trainer; not needed for this check
out = module.training_step(batch)
out["loss"].backward()
g_imp = sum(float(p.grad.abs().sum()) for p in module.imputer.parameters() if p.grad is not None)
g_sem = sum(float(p.grad.abs().sum()) for p in module.sem_module.parameters() if p.grad is not None)
assert torch.isfinite(out["loss"]), "loss is not finite"
assert g_imp > 0 and g_sem > 0, "gradient must reach the imputer and the DECI model"
groups = [g["name"] for g in module.configure_optimizers().param_groups]
assert "imputer" in groups and "imputer" in module.auglag_config.lr_init_dict
print(f"OK  loss={float(out['loss']):.3f}  imputation_entropy={float(out['imputation_entropy']):.3f}  "
      f"reconstruction={float(out['reconstruction_err']):.3f}  |grad imputer|={g_imp:.1f}  |grad DECI|={g_sem:.1f}  groups={groups}")
