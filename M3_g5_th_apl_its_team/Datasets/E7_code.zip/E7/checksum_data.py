"""
checksum_data.py - make sure the E7 data are byte-identical on every device.

    python checksum_data.py --verify data/E7        # compares every file with MANIFEST_E7.sha256 (exit code 1 on any mismatch)
    python checksum_data.py --write  data/E7        # (re)writes the manifest; only the person who freezes the data does this
"""
import argparse
import hashlib
import os
import sys

MANIFEST = "MANIFEST_E7.sha256"


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def files(root):
    out = []
    for d, _, fs in os.walk(root):
        out += [os.path.relpath(os.path.join(d, f), root) for f in fs if f != MANIFEST]
    return sorted(out)


p = argparse.ArgumentParser()
g = p.add_mutually_exclusive_group(required=True)
g.add_argument("--verify", metavar="DIR")
g.add_argument("--write", metavar="DIR")
a = p.parse_args()
if a.write:
    with open(os.path.join(a.write, MANIFEST), "w") as f:
        for rel in files(a.write):
            f.write(f"{digest(os.path.join(a.write, rel))}  {rel}\n")
    print(f"wrote {MANIFEST} for {len(files(a.write))} files")
else:
    expected = dict(line.strip().split("  ", 1)[::-1] for line in open(os.path.join(a.verify, MANIFEST)) if line.strip())
    bad = [r for r in set(expected) | set(files(a.verify))
           if r not in expected or not os.path.exists(os.path.join(a.verify, r)) or digest(os.path.join(a.verify, r)) != expected[r]]
    print("DATA IDENTICAL on all %d files" % len(expected) if not bad else "MISMATCH in %d file(s), e.g. %s" % (len(bad), sorted(bad)[:3]))
    sys.exit(1 if bad else 0)
