"""
deci_missing.py - the E7 BASELINE: DECI with amortised imputation, for Causica 0.4.6.

Causica 0.4.6 cannot train on missing values (its training_step expects a complete batch). The DECI
paper's missing-data extension (Section 3.4, ELBO Eq. 15) lives in the old v0.0.0 code base. This file
re-implements it inside 0.4.6 WITHOUT editing the library: a data module that carries the observation
mask, and a DECIModule subclass with one extra network (the imputer) and a new training_step.

What is ported from v0.0.0 (causica/models/deci/deci.py) and what is not
  ported   imputer = MLP on [x * mask, mask] -> mean and log-scale of an independent Gaussian for every
           variable (log-scale clipped to [-20, 5]); hidden layers [max(80, 2D)] * 2, LeakyReLU, layer norm
           (not before the first layer), residual connection where widths match, no final activation.
  ported   missing entries are filled with a reparameterised sample; the ELBO gains the entropy of the
           imputation distribution on the missing entries (summed over variables, averaged over rows).
  ported   the "reconstruction regulariser": the imputer sees a copy of the data with extra randomly
           dropped entries (max_p_train_dropout = 0.6) and is penalised for the squared error of its mean
           on the observed entries (reconstruction_loss_factor = 1.0). The DECI paper does not describe this.
  ported   the imputer NEVER sees the graph G. This is the property the proposed method changes.
  differs  0.4.6 training machinery (per-module learning rates, augmented-Lagrangian scheduler, batch
           size, node-embedding functional relationships). The imputer gets its own optimiser group with
           learning rate --imputer-lr (default 1e-3; v0.0.0 used one learning rate for all parameters).
  differs  only all-continuous data is supported (same restriction as v0.0.0).

Data are z-scored with statistics computed over the OBSERVED entries; missing entries are set to 0
(the mean) and carried together with a 0/1 observation mask.
"""
import numpy as np
import pandas as pd
import torch
import torch.distributions as td
from tensordict import TensorDict
from torch import nn

from causica.graph.dag_constraint import calculate_dagness
from causica.lightning.data_modules.basic_data_module import BasicDECIDataModule
from causica.lightning.modules.deci_module import DECIModule
from causica.training.auglag import AugLagLRConfig

MASK_KEY = "__mask__"     # extra key in every training batch; 1 = observed, 0 = missing


# ----------------------------------------------------------------------------
# helpers (no Causica needed)
# ----------------------------------------------------------------------------
def standardise_with_mask(df: pd.DataFrame):
    """z-score every column with its observed entries only. Returns (z, mask, mean, std) as numpy arrays;
    z has 0 in the missing positions, mask is float32 with 1 = observed."""
    arr = df.to_numpy(dtype=np.float64)
    mask = ~np.isnan(arr)
    mean = np.nanmean(arr, axis=0)
    std = np.nanstd(arr, axis=0, ddof=1)
    std = np.where(std < 1e-12, 1.0, std)
    z = (arr - mean) / std
    z[~mask] = 0.0
    return z.astype(np.float32), mask.astype(np.float32), mean, std


class _Residual(nn.Module):
    def __init__(self, block: nn.Module):
        super().__init__()
        self.block = block

    def forward(self, x):
        return x + self.block(x)


def make_imputer(num_nodes: int, hidden=None) -> nn.Module:
    """The v0.0.0 amortisation network: input [x * mask, mask] (2D) -> output [mean, logscale] (2D)."""
    d_in = d_out = 2 * num_nodes
    h = hidden or [max(80, d_in)] * 2
    layers, prev = [], d_in
    for idx, width in enumerate(h):
        block = []
        if idx > 0:
            block.append(nn.LayerNorm(prev))
        block += [nn.Linear(prev, width), nn.LeakyReLU()]
        seq = nn.Sequential(*block)
        layers.append(_Residual(seq) if prev == width else seq)
        prev = width
    layers += [nn.LayerNorm(prev), nn.Linear(prev, d_out)]
    return nn.Sequential(*layers)


# ----------------------------------------------------------------------------
# data module: BasicDECIDataModule + observation mask
# ----------------------------------------------------------------------------
class MissingDECIDataModule(BasicDECIDataModule):
    """Like BasicDECIDataModule(normalize=True) but tolerant to NaN. Every batch also carries MASK_KEY."""

    def __init__(self, dataframe: pd.DataFrame, variables, batch_size: int, dataset_name: str = "e7"):
        z, mask, self.col_mean, self.col_std = standardise_with_mask(dataframe)
        z_df = pd.DataFrame(z, columns=dataframe.columns)
        super().__init__(dataframe=z_df, variables=variables, batch_size=batch_size,
                         normalize=False, dataset_name=dataset_name)
        self.obs_mask = mask                                   # numpy (N, D)
        # variable_shapes / variable_types were fixed in the parent __init__ BEFORE this key is added,
        # so the DECI module still sees exactly D one-dimensional variables.
        self._dataset_train[MASK_KEY] = torch.as_tensor(mask)  # (N, D)


# ----------------------------------------------------------------------------
# module: DECI + amortised imputation (graph-agnostic, as in the paper)
# ----------------------------------------------------------------------------
class DECIModuleMissing(DECIModule):
    def __init__(self, *args, imputer_lr: float = 1e-3, max_p_train_dropout: float = 0.6,
                 reconstruction_loss_factor: float = 1.0, imputer_hidden=None, **kwargs):
        cfg = kwargs.pop("auglag_config", None) or AugLagLRConfig()
        cfg.lr_init_dict = {**cfg.lr_init_dict, "imputer": imputer_lr}   # the scheduler resets lr per group name
        super().__init__(*args, auglag_config=cfg, **kwargs)
        self.imputer_lr = imputer_lr
        self.max_p_train_dropout = max_p_train_dropout
        self.reconstruction_loss_factor = reconstruction_loss_factor
        self.imputer_hidden = imputer_hidden
        self.var_keys = None

    def setup(self, stage=None):
        already = self.is_setup
        super().setup(stage)
        if not already:
            self.var_keys = list(self.variable_group_shapes.keys())
            for k, shape in self.variable_group_shapes.items():
                assert int(np.prod(shape)) == 1, f"variable {k} has shape {tuple(shape)}; only scalar variables supported"
            self.imputer = make_imputer(len(self.var_keys), self.imputer_hidden)

    def configure_optimizers(self):
        optimizer = super().configure_optimizers()
        optimizer.add_param_group({"params": list(self.imputer.parameters()),
                                   "lr": self.auglag_config.lr_init_dict["imputer"], "name": "imputer"})
        return optimizer

    # -- the imputation distribution q_psi(x_u | x_o): note that it does not depend on the graph --------------
    def imputer_params(self, x: torch.Tensor, mask: torch.Tensor):
        out = self.imputer(torch.cat([x * mask, mask], dim=1))
        d = x.shape[1]
        mean = out[:, :d]
        scale = torch.exp(torch.clip(out[:, d:], min=-20, max=5))
        return mean, scale

    def training_step(self, *args, **kwargs):
        batch, *_ = args
        assert self.num_samples is not None
        batch = batch.apply(lambda t: t.to(torch.float32, non_blocking=True))
        mask = batch[MASK_KEY]                                          # (B, D), 1 = observed
        x = torch.cat([batch[k] for k in self.var_keys], dim=-1)        # (B, D), 0 where missing
        n_rows = x.shape[0]

        # (1) reconstruction regulariser: extra random dropout of observed entries, squared error on observed
        p_missing = torch.rand(n_rows, 1, device=x.device) * self.max_p_train_dropout
        input_mask = mask * torch.bernoulli(1.0 - p_missing.expand_as(mask))
        mean_rec, _ = self.imputer_params(x, input_mask)
        reconstruction = (mask * (mean_rec - x) ** 2).sum(dim=1).mean()

        # (2) fill in the missing entries with a reparameterised sample from q_psi(x_u | x_o)
        if bool((mask == 1).all()):                                     # complete batch: nothing to impute
            x_fill = x
            imputation_entropy = x.new_zeros(())
        else:
            mean, scale = self.imputer_params(x, mask)
            dist = td.Normal(mean, scale)
            x_fill = x * mask + dist.rsample() * (1.0 - mask)
            imputation_entropy = (dist.entropy() * (1.0 - mask)).sum(dim=1).mean()
        batch_fill = TensorDict({k: x_fill[:, i:i + 1] for i, k in enumerate(self.var_keys)},
                                batch_size=batch.batch_size, device=batch.device)

        # (3) the usual DECI terms on the filled batch
        sem_distribution = self.sem_module()
        sem, *_ = sem_distribution.relaxed_sample(torch.Size([]), temperature=self.gumbel_temp)
        batch_log_prob = sem.log_prob(batch_fill).mean()
        sem_distribution_entropy = sem_distribution.entropy()
        prior_term = self.prior.log_prob(sem.graph)
        objective = (-sem_distribution_entropy - prior_term) / self.num_samples - batch_log_prob - imputation_entropy
        constraint = calculate_dagness(sem.graph)
        loss = (self.auglag_loss(objective, constraint / self.num_samples)
                + self.reconstruction_loss_factor * reconstruction)

        step_output = {
            "alpha": self.auglag_loss.alpha,
            "rho": self.auglag_loss.rho,
            "loss": loss,
            "batch_log_prob": batch_log_prob,
            "constraint": constraint,
            "num_edges": (sem.graph > 0.0).count_nonzero(),
            "vardist_entropy": sem_distribution_entropy,
            "prior_term": prior_term,
            "imputation_entropy": imputation_entropy,
            "reconstruction_err": reconstruction,
        }
        self.log_dict(step_output, on_epoch=True)
        return step_output

    @torch.no_grad()
    def imputation_report(self, z: np.ndarray, mask: np.ndarray, z_true: np.ndarray) -> dict:
        """Quality of the imputation distribution on the MISSING training entries, in z-score units.
        rmse: error of the imputer mean; rmse_mean_fill: error of filling with the column mean (0);
        nll: mean negative log density of the true value under the Gaussian q_psi."""
        self.eval()
        x = torch.as_tensor(z, dtype=torch.float32, device=self.device)
        m = torch.as_tensor(mask, dtype=torch.float32, device=self.device)
        mean, scale = self.imputer_params(x, m)
        miss = (m == 0)
        if not bool(miss.any()):
            return dict(impute_rmse=None, impute_rmse_mean_fill=None, impute_nll=None, n_missing=0)
        truth = torch.as_tensor(z_true, dtype=torch.float32, device=self.device)
        err = (mean - truth)[miss]
        nll = -td.Normal(mean, scale).log_prob(truth)[miss]
        return dict(impute_rmse=float(err.pow(2).mean().sqrt()),
                    impute_rmse_mean_fill=float(truth[miss].pow(2).mean().sqrt()),
                    impute_nll=float(nll.mean()), n_missing=int(miss.sum()))
