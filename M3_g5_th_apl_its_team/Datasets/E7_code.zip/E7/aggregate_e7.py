"""
aggregate_e7.py - Table 6 (E7, missingness) from e7_per_run.csv, plus the P-5 sanity check.

    python aggregate_e7.py --results results/E7_lambda5 --out results/E7_lambda5/summary
    python aggregate_e7.py --results results/E7_lambda5 --out results/E7_lambda5/summary \
        --ref-results results/E1_lambda5 --ref-data data/E1          # adds the P-5 check against your E1 runs

For every (variant, method, regime) a table with one row per missing rate:
    Expected SHD, Adj. F1, Orient. F1, Imputation RMSE (and the mean-fill reference), Runtime (h), runs ok/expected.
Cells are mean +/- sample SD (n-1) over seeds. A cell with no run reads "Not run".
Imputation RMSE is in z-score units of the observed entries; the mean-fill column is the RMSE of filling a missing
entry with the column mean, so the imputer is only useful where its RMSE is clearly below that column.

P-5 (needs --ref-results/--ref-data): the nonlinear regime at 0 % missing uses the E1 data and the E1 code path, so its
expected SHD / F1 should equal your E1 runs for the same seeds up to hardware nondeterminism.
"""
import argparse
import glob
import os

import numpy as np
import pandas as pd

from metrics import expected_metrics

COLS = [("expected_shd", "Expected SHD", 2), ("expected_adj_f1", "Adj. F1", 3), ("expected_orient_f1", "Orient. F1", 3),
        ("impute_rmse", "Imputation RMSE", 3), ("impute_rmse_mean_fill", "Mean-fill RMSE", 3), ("runtime_h", "Runtime (h)", 2)]


def cell(x, nd):
    x = pd.Series(x).dropna().astype(float)
    if len(x) == 0:
        return "Not run"
    sd = x.std(ddof=1) if len(x) > 1 else float("nan")
    return f"{x.mean():.{nd}f} ± {sd:.{nd}f}" if len(x) > 1 else f"{x.mean():.{nd}f} (1 seed)"


def build_table(df: pd.DataFrame, rates):
    rows = []
    for r in rates:
        sub = df[df.missing_rate == r]
        ok = sub[sub.status == "ok"]
        row = {"Missing rate": f"{r} %"}
        for key, label, nd in COLS:
            if key not in ok.columns or ok[key].dropna().empty:
                row[label] = "—" if key.startswith("impute") and len(ok) else "Not run"
            else:
                row[label] = cell(ok[key], nd)
        row["Runs ok / found"] = f"{len(ok)} / {len(sub)}"
        rows.append(row)
    return pd.DataFrame(rows)


def p5_check(per_run: pd.DataFrame, ref_results: str, ref_data: str) -> pd.DataFrame:
    rows = []
    sub = per_run[(per_run.regime == "nonlinear") & (per_run.missing_rate == 0) & (per_run.status == "ok")]
    for _, r in sub.iterrows():
        name = f"er{r.D}_{r.D}_n{r.n_train}_seed{r.seed}"
        sp = os.path.join(ref_results, r.variant, name, "posterior_samples.npy")
        ap = os.path.join(ref_data, name, "adj_matrix.csv")
        if not (os.path.exists(sp) and os.path.exists(ap)):
            rows.append(dict(variant=r.variant, method=r.method, seed=r.seed, note="no reference run found"))
            continue
        m = expected_metrics((np.load(sp) > 0.5).astype(int), np.loadtxt(ap, delimiter=",", ndmin=2).astype(int))
        rows.append(dict(variant=r.variant, method=r.method, seed=r.seed, e7_shd=r.expected_shd, ref_shd=m["expected_shd"],
                         diff_shd=r.expected_shd - m["expected_shd"], e7_adj_f1=r.expected_adj_f1,
                         ref_adj_f1=m["expected_adj_f1"], diff_adj_f1=r.expected_adj_f1 - m["expected_adj_f1"]))
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default="results/E7_lambda5")
    parser.add_argument("--out", default="results/E7_lambda5/summary")
    parser.add_argument("--ref-results", default=None)
    parser.add_argument("--ref-data", default=None)
    args = parser.parse_args()
    per_run = pd.read_csv(os.path.join(args.results, "e7_per_run.csv"))
    os.makedirs(args.out, exist_ok=True)
    rates = sorted(per_run.missing_rate.unique())
    all_rows = []
    for (variant, method, regime), g in per_run.groupby(["variant", "method", "regime"]):
        t = build_table(g, rates)
        t.insert(0, "Regime", regime); t.insert(0, "Method", method); t.insert(0, "Variant", variant)
        all_rows.append(t)
        base = os.path.join(args.out, f"table6_{variant}_{method}_{regime}")
        t.drop(columns=["Variant", "Method", "Regime"]).to_csv(base + ".csv", index=False)
        with open(base + ".md", "w") as f:
            f.write(f"Table 6 ({variant}, {method}, {regime} regime): mean ± SD over seeds\n\n")
            f.write(t.drop(columns=["Variant", "Method", "Regime"]).to_markdown(index=False))
        print(f"\n{variant} / {method} / {regime}\n" + t.drop(columns=["Variant", "Method", "Regime"]).to_string(index=False))
    pd.concat(all_rows).to_csv(os.path.join(args.out, "table6_all.csv"), index=False)

    ok = per_run[per_run.status == "ok"]
    if len(ok):
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        regimes = sorted(ok.regime.dropna().unique())
        fig, axes = plt.subplots(2, len(regimes), figsize=(5.2 * len(regimes), 7), squeeze=False)
        for j, regime in enumerate(regimes):
            for (variant, method), g in ok[ok.regime == regime].groupby(["variant", "method"]):
                for i, (key, label) in enumerate([("expected_shd", "Expected SHD"), ("expected_adj_f1", "Adj. F1")]):
                    agg = g.groupby("missing_rate")[key].agg(["mean", "std"]).reset_index()
                    axes[i][j].errorbar(agg.missing_rate, agg["mean"], yerr=agg["std"].fillna(0), marker="o",
                                        capsize=3, label=f"{variant} {method}")
                    axes[i][j].set_xlabel("Missing rate (%)"); axes[i][j].set_ylabel(label)
                    axes[i][j].set_title(f"{regime}")
            axes[0][j].legend(fontsize=8)
        fig.tight_layout(); fig.savefig(os.path.join(args.out, "e7_vs_missing.png"), dpi=150)

    if args.ref_results and args.ref_data:
        p5 = p5_check(per_run, args.ref_results, args.ref_data)
        p5.to_csv(os.path.join(args.out, "p5_sanity_check.csv"), index=False)
        print("\nP-5 sanity check (E7 at 0 % missing vs your E1 runs, same data and seeds):\n" + p5.round(3).to_string(index=False))
    print(f"\n-> {args.out}")


if __name__ == "__main__":
    main()
