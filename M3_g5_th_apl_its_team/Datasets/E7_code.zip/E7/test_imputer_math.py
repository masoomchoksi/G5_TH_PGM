"""
test_imputer_math.py - is the imputer's ELBO implemented correctly?

The REAL DECIModuleMissing.training_step is run with a stand-in for the structural model: the data come from a known
4-variable Gaussian N(0, Sigma) and the "SEM" is that exact density (log p = MVN log-density, graph entropy 0, prior 0).
Then only the imputer is trained on the pure ELBO (reconstruction factor 0). For a Gaussian joint the exact posterior
of the missing entries given the observed ones is Gaussian, and the best DIAGONAL Gaussian q (the imputer's family)
has
    mean      = exact conditional mean                       mu_{u|o}
    variance  = 1 / diag( inv(Sigma_{u|o}) )                 (mean-field optimum of KL(q || p))
So a correct ELBO (right sign of the entropy, right fill-in, right masking) must reproduce these numbers.

    /content/venv310/bin/python test_imputer_math.py          (about 2-3 minutes on CPU)

Also checked: observed entries are never changed by the fill-in, the reconstruction term enters the loss exactly once
with the factor, a complete batch is a no-op for the fill-in, and the ELBO gradient (not only the reconstruction
gradient) reaches the imputer.
"""
import torch  # noqa: F401  must stay first
import os
os.environ["MPLBACKEND"] = "Agg"

import numpy as np
from tensordict import TensorDict
from torch import nn

from causica.distributions.noise.joint import ContinuousNoiseDist
from deci_missing import MASK_KEY, DECIModuleMissing, make_imputer

torch.manual_seed(0)
np.random.seed(0)
D, N = 4, 8000
SIGMA = torch.tensor([[1.0, 0.8, 0.5, 0.2],
                      [0.8, 1.0, 0.6, 0.3],
                      [0.5, 0.6, 1.0, 0.7],
                      [0.2, 0.3, 0.7, 1.0]], dtype=torch.float32)
KEYS = [f"x{i}" for i in range(D)]
MVN = torch.distributions.MultivariateNormal(torch.zeros(D), SIGMA)


class FakeSEM:
    graph = torch.zeros(D, D)
    seen = None

    def log_prob(self, td):
        FakeSEM.seen = td.clone()
        return MVN.log_prob(torch.cat([td[k] for k in KEYS], dim=-1))


class FakeDist:
    def relaxed_sample(self, shape, temperature):
        return FakeSEM(), None

    def entropy(self):
        return torch.zeros(())


class FakeSEMModule(nn.Module):
    def forward(self):
        return FakeDist()


class FakePrior(nn.Module):
    def log_prob(self, graph):
        return torch.zeros(())


def make_module(recon_factor):
    m = DECIModuleMissing(noise_dist=ContinuousNoiseDist.GAUSSIAN, reconstruction_loss_factor=recon_factor)
    m.var_keys = KEYS
    m.imputer = make_imputer(D)
    m.num_samples = N
    m.sem_module = FakeSEMModule()
    m.prior = FakePrior()
    m.log_dict = lambda *a, **k: None
    m.train()
    return m


def make_batch(x, mask):
    return TensorDict({k: x[:, i:i + 1] * mask[:, i:i + 1] for i, k in enumerate(KEYS)} | {MASK_KEY: mask},
                      batch_size=[x.shape[0]])


X = MVN.sample((N,))
MASK = (torch.rand(N, D) > 0.4).float()
MASK[MASK.sum(1) == 0, 0] = 1.0
results = []

# ---- Test 1: the ELBO-trained imputer recovers the exact mean-field posterior ---------------------------------------
module = make_module(recon_factor=0.0)
STEPS = 8000                      # stochastic ELBO gradients are noisy: use a decaying learning rate (3000 fixed-lr steps leave an RMSE ~0.065)
opt = torch.optim.Adam(module.imputer.parameters(), lr=3e-3)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=STEPS, eta_min=1e-5)
for step in range(STEPS):
    idx = torch.randint(0, N, (512,))
    loss = module.training_step(make_batch(X[idx], MASK[idx]))["loss"]
    opt.zero_grad()
    loss.backward()
    opt.step()
    sched.step()
module.eval()
with torch.no_grad():
    mean, scale = module.imputer_params(X * MASK, MASK)
mean_err, scale_rel, scale_rel_marg = [], [], []
S = SIGMA.numpy().astype(np.float64)
for r in range(1500):
    o = np.where(MASK[r].numpy() > 0)[0]
    u = np.where(MASK[r].numpy() == 0)[0]
    if len(u) == 0:
        continue
    Soo, Suo, Suu = S[np.ix_(o, o)], S[np.ix_(u, o)], S[np.ix_(u, u)]
    mu = Suo @ np.linalg.solve(Soo, X[r, o].numpy())
    Sc = Suu - Suo @ np.linalg.solve(Soo, Suo.T)
    sd_opt = np.sqrt(1.0 / np.diag(np.linalg.inv(Sc)))
    sd_marg = np.sqrt(np.diag(Sc))
    mean_err += list(mean[r, u].numpy() - mu)
    scale_rel += list(scale[r, u].numpy() / sd_opt - 1.0)
    scale_rel_marg += list(scale[r, u].numpy() / sd_marg - 1.0)
rmse_mean = float(np.sqrt(np.mean(np.square(mean_err))))
mae_scale = float(np.mean(np.abs(scale_rel)))
print(f"[1] imputer mean vs exact conditional mean: RMSE = {rmse_mean:.4f}  (exact answer has spread ~1; must be < 0.05)")
print(f"[1] imputer scale vs mean-field optimum 1/sqrt(diag precision): mean |relative error| = {mae_scale:.3f}  (must be < 0.10)")
print(f"    (for reference: relative gap to the exact conditional marginal sd = {np.mean(np.abs(scale_rel_marg)):.3f}; "
      f"a diagonal Gaussian is expected to be a bit narrower when several entries are missing)")
results.append(("ELBO-trained imputer = exact mean-field posterior", rmse_mean < 0.05 and mae_scale < 0.10))

# ---- Test 2: observed entries are untouched by the fill-in ----------------------------------------------------------
m2 = make_module(recon_factor=1.0)
idx = torch.arange(256)
batch = make_batch(X[idx], MASK[idx])
m2.training_step(batch)
filled = torch.cat([FakeSEM.seen[k] for k in KEYS], dim=-1)
obs = MASK[idx] > 0
same_obs = bool(torch.allclose(filled[obs], (X[idx] * MASK[idx])[obs]))
changed_missing = bool((filled[~obs] != 0).any())
print(f"[2] observed entries unchanged: {same_obs} | missing entries were filled (non-zero): {changed_missing}")
results.append(("fill-in keeps observed, fills missing", same_obs and changed_missing))

# ---- Test 3: reconstruction term enters the loss exactly once, with its factor --------------------------------------
m_a, m_b = make_module(1.0), make_module(0.0)
m_b.imputer.load_state_dict(m_a.imputer.state_dict())
torch.manual_seed(123)
out_a = m_a.training_step(batch)
torch.manual_seed(123)
out_b = m_b.training_step(batch)
diff = float((out_a["loss"] - out_b["loss"]).detach())
rec = float(out_a["reconstruction_err"].detach())
print(f"[3] loss(factor 1) - loss(factor 0) = {diff:.6f}  vs reconstruction_err = {rec:.6f}")
results.append(("reconstruction term enters once", abs(diff - rec) < 1e-4))

# ---- Test 4: the ELBO gradient itself (not only the reconstruction gradient) reaches the imputer --------------------
m_c = make_module(0.0)
m_c.training_step(batch)["loss"].backward()
g = sum(float(p.grad.abs().sum()) for p in m_c.imputer.parameters() if p.grad is not None)
print(f"[4] |grad| of the imputer with reconstruction factor 0: {g:.4f}  (must be > 0)")
results.append(("ELBO gradient reaches the imputer", g > 0))

# ---- Test 5: a complete batch is a no-op for the fill-in ------------------------------------------------------------
m_d = make_module(0.0)
full = make_batch(X[:128], torch.ones(128, D))
out_d = m_d.training_step(full)
x_seen = torch.cat([FakeSEM.seen[k] for k in KEYS], dim=-1)
ok5 = bool(torch.allclose(x_seen, X[:128])) and float(out_d["imputation_entropy"]) == 0.0
print(f"[5] complete batch: data unchanged and imputation entropy = {float(out_d['imputation_entropy'])}")
results.append(("complete batch is a no-op", ok5))

print("\n" + "\n".join(f"{'PASS' if ok else 'FAIL'}  {name}" for name, ok in results))
raise SystemExit(0 if all(ok for _, ok in results) else 1)
