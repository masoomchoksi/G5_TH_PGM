# E2 (CSE 516 M2, Table 7): graph size D and the cyclic-sample rate, tests P6

Table 7a  DECI-G (main arm):       ER(D, D), D = 8, 12, 16, 20, 24, 32, seeds 0-2     -> 18 runs
Table 7b  DECI-S (validation arm): ER(D, D), D = 8, 24,                seeds 0-1     ->  4 runs
Columns: Expected SHD, Adj. F1, Cyclic-sample rate, Shortest cycle (median), Runtime (h).

## Design (log in the report)
* Same SEM family as E1: non-linear additive-noise model (random one-hidden-layer tanh MLPs), non-Gaussian warped noise,
  ER(D, D) = D nodes and D edges, a different random DAG for every (D, seed).
* Training size n is fixed at 1000 (ASSUMPTION: the table does not state n; change it with `--sizes`, see below).
* One 5000-row pool is sampled per (D, seed) and the training set is its first n rows, exactly as in E1. Consequence:
  ER(16,16) at n = 1000, seeds 0-2 is byte-for-byte the E1 dataset er16_16_n1000_seed{0,1,2}, so the D = 16 row of Table 7a
  can reuse the E1 DECI-G lambda = 5 runs (copy results/E1_lambda5/deci_g/er16_16_n1000_seed{0,1,2} into
  results/E2_lambda5/deci_g/). Optional; running everything fresh is also fine.
* DECI settings: Causica 0.4.6, lambda_s = 5 (`--sparsity-lambda 5`), otherwise defaults (see train_deci.py docstring).
* 100 graphs are drawn from the learned posterior q(G). They are hard (binary) samples, so some contain directed cycles.
  Cyclic-sample rate = fraction of the 100 samples that are not DAGs. Cyclic samples ARE included in expected SHD / F1.
* Shortest cycle (median): for every cyclic sample, the length of its shortest directed cycle (self-loop = 1, 2-cycle = 2);
  the cell is the median over all cyclic samples of all seeds of that row ("none cyclic" if there were none).
* SHD counts a reversed edge as 1. Cells are mean +/- sample SD (n-1) over seeds. A cell with no run reads "Not run".
* P6 is tested with a regression slope of the per-run cyclic rate on D (95% CI) in p6_trend.csv, not read off a plot.
* Runtime (h) is wall-clock training time from training_log.json; it depends on the hardware, so log the GPU/CPU used.

## Environments (two, because Causica 0.4.6 needs Python 3.10)
A (DECI):  Python 3.10 ->  pip install causica==0.4.6 pandas numpy          (train_deci.py)
B (rest):  any Python  ->  pip install pandas numpy scipy matplotlib tabulate   (score_e2.py, aggregate_e2.py)
Keep this folder together; scripts use relative paths (data/E2, results/E2_lambda5).

## Run order
1. check the data (optional)   python data_generation.py --out data --validate-only
2. DECI-G main arm, env A      python train_deci.py --variant deci_g --data data/E2 --results results/E2_lambda5 --sparsity-lambda 5 --progress --only <names>
3. DECI-S validation, env A    python train_deci.py --variant deci_s --data data/E2 --results results/E2_lambda5 --sparsity-lambda 5 --progress --only <names>
4. score every run, env B      python score_e2.py --data data/E2 --results results/E2_lambda5
5. tables + plot, env B        python aggregate_e2.py --results results/E2_lambda5 --out results/E2_lambda5/summary

<names> for step 2: er{D}_{D}_n1000_seed{0,1,2} for D in 8 12 16 20 24 32, e.g. er8_8_n1000_seed0 er8_8_n1000_seed1 ...
<names> for step 3: er{D}_{D}_n1000_seed{0,1} for D in 8 24.
Without --only, train_deci.py would run all 18 datasets for that variant. Finished runs are skipped on restart.
Other training size, e.g. 2500:  python data_generation.py --out data --sizes 2500 --overwrite   (folders er{D}_{D}_n2500_seed{s}).

## Outputs (results/E2_lambda5/summary)
table7a / table7b (.csv .md .png), table7_counts.csv (ok/failed/missing/converged per row), p6_trend.csv, e2_vs_D.png.
Rows where not every seed converged are visible in table7_counts.csv; say so in the caption.

## Files
data_generation.py  E2 data (+ E1 grid) + validation     metrics.py   SHD, F1, cyclic rate, shortest cycle (new)
train_deci.py       DECI-S/-G training (unchanged from E1)  deci_interface.py   imported by train_deci.py
score_e2.py         per-run KPIs incl. cycle lengths      aggregate_e2.py   Table 7a/7b, trend, plot
