"""Baseline vs Graph-Aware DECI: heatmaps + DAG comparison.
Usage: python3 compare_deci.py <dir with E7 zips> <out dir> [truth.npz]
truth.npz (optional): keys like 'seed0' -> 16x16 true adjacency; adds accuracy panels/metrics."""
import sys, os, re, io, json, glob, zipfile, itertools
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, networkx as nx
from matplotlib.colors import TwoSlopeNorm
from matplotlib.lines import Line2D

SRC, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
TRUTH = np.load(sys.argv[3]) if len(sys.argv) > 3 else None
BLUE, ORANGE, GREY, INK = "#2a6fb0", "#d9731a", "#9a9a9a", "#222222"
plt.rcParams.update({"font.size": 9, "axes.edgecolor": "#888", "figure.dpi": 130})

# ---------- load (handles nested zips, dedupes repeated runs) ----------
runs = {}
def ingest(zf):
    for n in zf.namelist():
        if n.endswith(".zip"):
            ingest(zipfile.ZipFile(io.BytesIO(zf.read(n))))
        elif n.endswith("posterior_samples.npy"):
            d = os.path.dirname(n); name = d.split("/")[-1]; var = d.split("/")[-2]
            m = re.match(r"er16_16_n1000_(\w+)_seed(\d+)_miss(\d+)", name)
            if not m: continue
            algo = "DECI-G" if var.startswith("deci_g") else "DECI-S"
            arm = "proposed" if "graphaware" in var else "baseline"
            log = json.loads(zf.read(d + "/training_log.json"))
            runs[(algo, arm, m[1], int(m[2]), int(m[3]))] = dict(
                S=np.load(io.BytesIO(zf.read(n))).astype(float), log=log)
for z in glob.glob(SRC + "/**/*.zip", recursive=True):
    ingest(zipfile.ZipFile(z))
print("unique runs:", len(runs))

ALGOS, REGS, SEEDS, MISS = ["DECI-G", "DECI-S"], ["lingauss", "nonlinear"], [0, 1, 2], [0, 10, 30, 50]
def P(a, arm, r, s, m):  # edge probability matrix (row=cause, col=effect)
    k = (a, arm, r, s, m)
    if m == 0: k = (a, "baseline", r, s, 0)   # 0% missing: both arms identical (no imputation)
    return runs[k]["S"].mean(0)
def C(p): return (p >= .5).astype(int)
def shd(a, b):  # structural Hamming distance, reversal counts 1
    d = np.abs(a - b); return int(((d + d.T) > 0).sum() / 2 + (np.triu(d + d.T) == 1).sum() * 0) if False else int(
        sum(1 for i, j in itertools.combinations(range(16), 2) if (a[i, j], a[j, i]) != (b[i, j], b[j, i])))
def l1(a, b): return float(np.abs(a - b).mean())

# ---------- metrics table ----------
rows = []
for a, r, s, m in itertools.product(ALGOS, REGS, SEEDS, MISS):
    for arm in ["baseline", "proposed"]:
        p, p0 = P(a, arm, r, s, m), P(a, arm, r, s, 0)
        lg = runs[(a, arm if m else "baseline", r, s, m)]["log"]
        row = dict(algo=a, arm=arm, regime=r, seed=s, miss=m,
                   mean_edges=p.sum(), consensus_edges=C(p).sum(),
                   mean_abs_dev_from_complete=l1(p, p0), shd_to_complete=shd(C(p), C(p0)),
                   elbo=lg["final_elbo"], runtime_h=lg["runtime_s"] / 3600,
                   impute_rmse=lg.get("impute_rmse"), meanfill_rmse=lg.get("impute_rmse_mean_fill"),
                   mean_entropy=float(np.mean(-(p * np.log(p + 1e-9) + (1 - p) * np.log(1 - p + 1e-9)))))
        if TRUTH is not None and f"seed{s}" in TRUTH:
            T = TRUTH[f"seed{s}"].astype(int); c = C(p)
            tp = (c * T).sum(); row.update(shd_to_truth=shd(c, T), precision=tp / max(c.sum(), 1), recall=tp / T.sum())
        rows.append(row)
df = pd.DataFrame(rows); df.to_csv(f"{OUT}/metrics_per_run.csv", index=False)
num = df.select_dtypes("number").columns.drop(["seed", "miss"])
summ = df.groupby(["algo", "regime", "miss", "arm"])[list(num)].agg(["mean", "std"]).round(3)
summ.to_csv(f"{OUT}/metrics_summary_mean_sd.csv")

# ---------- Fig set 1: heatmaps ----------
def heat(ax, M, cmap="Blues", vmin=0, vmax=1, norm=None, title=None):
    im = ax.imshow(M, cmap=cmap, vmin=None if norm else vmin, vmax=None if norm else vmax, norm=norm)
    ax.set_xticks(range(16)); ax.set_yticks(range(16))
    ax.set_xticklabels(range(16), fontsize=5); ax.set_yticklabels(range(16), fontsize=5)
    ax.tick_params(length=0)
    if title: ax.set_title(title, fontsize=9, color=INK)
    return im
for a, r, s in itertools.product(ALGOS, REGS, SEEDS):
    fig, axs = plt.subplots(3, 5, figsize=(14, 8.6), constrained_layout=True)
    for i, m in enumerate([10, 30, 50]):
        b, p, p0 = P(a, "baseline", r, s, m), P(a, "proposed", r, s, m), P(a, "baseline", r, s, 0)
        i1 = heat(axs[i, 0], p0, title="Complete data (0%)" if i == 0 else None)
        heat(axs[i, 1], b, title="Baseline" if i == 0 else None)
        heat(axs[i, 2], p, title="Graph-aware (proposed)" if i == 0 else None)
        i3 = heat(axs[i, 3], p - b, cmap="RdBu_r", norm=TwoSlopeNorm(0, -1, 1),
                  title="Δ proposed − baseline" if i == 0 else None)
        # which arm is closer to the complete-data posterior
        db, dp = np.abs(b - p0), np.abs(p - p0)
        i4 = heat(axs[i, 4], db - dp, cmap="PuOr", norm=TwoSlopeNorm(0, -1, 1),
                  title="Closer to complete data?\n(orange = proposed, purple = baseline)" if i == 0 else None)
        axs[i, 0].set_ylabel(f"{m}% missing\ncause (row)", fontsize=9)
        axs[i, 1].set_xlabel(f"mean edges {b.sum():.1f}", fontsize=8)
        axs[i, 2].set_xlabel(f"mean edges {p.sum():.1f}", fontsize=8)
        axs[i, 4].set_xlabel(f"|Δ| vs complete: base {db.mean():.3f}, prop {dp.mean():.3f}", fontsize=7)
    fig.colorbar(i1, ax=axs[:, :3], shrink=.5, label="P(edge i→j)", location="bottom", pad=.02)
    fig.colorbar(i3, ax=axs[:, 3:], shrink=.5, label="difference in P(edge)", location="bottom", pad=.02)
    fig.suptitle(f"{a} · {r} · seed {s} — posterior edge probabilities (100 samples)", fontsize=12)
    fig.savefig(f"{OUT}/heatmap_{a}_{r}_seed{s}.png"); plt.close(fig)

# ---------- Fig set 2: DAGs ----------
def acyclic_consensus(p):  # threshold, then drop weakest edge in each cycle so it's a DAG
    c = C(p); G = nx.DiGraph([(i, j) for i, j in zip(*np.nonzero(c))]); G.add_nodes_from(range(16))
    while True:
        try: cyc = nx.find_cycle(G)
        except nx.NetworkXNoCycle: return G
        u, v = min(cyc, key=lambda e: p[e[0], e[1]]); G.remove_edge(u, v)
def layout(G):  # layered by topological generation of a reference DAG, falls back to circle
    return nx.circular_layout(range(16))
pos = nx.circular_layout(range(16))
def draw(ax, E_shared, E_a, E_b, title, la, lb):
    ax.set_title(title, fontsize=9); ax.axis("off"); ax.set_aspect("equal")
    nx.draw_networkx_nodes(nx.empty_graph(16), pos, ax=ax, node_size=170, node_color="white", edgecolors=INK, linewidths=.8)
    nx.draw_networkx_labels(nx.empty_graph(16), pos, ax=ax, font_size=6)
    kw = dict(pos=pos, ax=ax, arrows=True, arrowsize=7, node_size=170, connectionstyle="arc3,rad=0.08")
    nx.draw_networkx_edges(nx.DiGraph(list(E_shared)), edgelist=list(E_shared), edge_color=GREY, width=.9, **kw)
    nx.draw_networkx_edges(nx.DiGraph(list(E_a)), edgelist=list(E_a), edge_color=BLUE, width=1.2, **kw)
    nx.draw_networkx_edges(nx.DiGraph(list(E_b)), edgelist=list(E_b), edge_color=ORANGE, width=1.2, **kw)
for a, r, s in itertools.product(ALGOS, REGS, SEEDS):
    fig, axs = plt.subplots(3, 3, figsize=(11, 10.5), constrained_layout=True)
    for i, m in enumerate([10, 30, 50]):
        Gb, Gp = acyclic_consensus(P(a, "baseline", r, s, m)), acyclic_consensus(P(a, "proposed", r, s, m))
        G0 = acyclic_consensus(P(a, "baseline", r, s, 0))
        eb, ep, e0 = set(Gb.edges), set(Gp.edges), set(G0.edges)
        draw(axs[i, 0], eb & e0, eb - e0, e0 - eb, f"Baseline: {len(eb)} edges" if i else f"{m}%  Baseline: {len(eb)} edges", "", "")
        draw(axs[i, 1], ep & e0, ep - e0, e0 - ep, f"Proposed: {len(ep)} edges", "", "")
        draw(axs[i, 2], eb & ep, eb - ep, ep - eb, f"Baseline vs proposed\n(shared {len(eb & ep)}, only-base {len(eb - ep)}, only-prop {len(ep - eb)})", "", "")
        axs[i, 0].text(-.02, .5, f"{m}% missing", transform=axs[i, 0].transAxes, rotation=90, va="center", ha="right", fontsize=10)
    fig.get_layout_engine().set(rect=(0, 0.08, 1, 0.92))
    fig.legend(handles=[Line2D([], [], color=GREY, label="edge also in complete-data graph (cols 1–2) / in both (col 3)"),
                        Line2D([], [], color=BLUE, label="extra edge vs complete data (cols 1–2) / baseline only (col 3)"),
                        Line2D([], [], color=ORANGE, label="edge lost vs complete data (cols 1–2) / proposed only (col 3)")],
               loc="lower center", ncol=1, frameon=False, fontsize=8, bbox_to_anchor=(0.5, 0.0))
    fig.suptitle(f"{a} · {r} · seed {s} — consensus DAG (edge prob ≥ 0.5, cycles broken at weakest edge)", fontsize=12)
    fig.savefig(f"{OUT}/dag_{a}_{r}_seed{s}.png"); plt.close(fig)

# ---------- Fig 3: summary across missingness ----------
metrics = [("mean_edges", "Mean edges per sampled graph"), ("mean_abs_dev_from_complete", "Mean |ΔP(edge)| vs complete-data posterior"),
           ("shd_to_complete", "SHD of consensus DAG vs complete-data DAG"), ("impute_rmse", "Imputation RMSE (hidden entries)"),
           ("elbo", "Final ELBO"), ("runtime_h", "Training runtime (h)")]
for a in ALGOS:
    fig, axs = plt.subplots(2, 6, figsize=(18, 6), constrained_layout=True)
    for i, r in enumerate(REGS):
        for j, (k, t) in enumerate(metrics):
            ax = axs[i, j]
            for arm, col, mk in [("baseline", BLUE, "o"), ("proposed", ORANGE, "s")]:
                d = df[(df.algo == a) & (df.regime == r) & (df.arm == arm)]
                if k in ("impute_rmse",): d = d[d.miss > 0]
                g = d.groupby("miss")[k].agg(["mean", "std"])
                ax.errorbar(g.index, g["mean"], g["std"], color=col, marker=mk, ms=5, lw=1.6, capsize=3, label=arm)
            ax.set_title(t if i == 0 else "", fontsize=9); ax.set_xticks(MISS); ax.grid(alpha=.25)
            ax.set_xlabel("% missing"); 
            if j == 0: ax.set_ylabel(r, fontsize=10)
    axs[0, 0].legend(frameon=False)
    fig.suptitle(f"{a} — baseline vs graph-aware (mean ± SD over 3 seeds)", fontsize=12)
    fig.savefig(f"{OUT}/summary_{a}.png"); plt.close(fig)

# ---------- Fig 4: pooled per-edge-slot comparison to complete data ----------
print(summ.xs(("DECI-G",), level=0).iloc[:, :0].shape)
agg = df[df.miss > 0].groupby(["algo", "regime", "miss", "arm"])[["mean_edges", "mean_abs_dev_from_complete", "shd_to_complete", "impute_rmse", "runtime_h"]].mean().round(3)
print(agg.to_string())
