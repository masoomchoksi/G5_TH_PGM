# E4–E5 — CSuite replication experiment (CSE 516 M2, Table 5)

This folder contains the E4/E5 implementation. Run every command from the **repository root** (`Code/`).

## Experiment design

- Four CSuite datasets: `lingauss`, `linexp`, `nonlingauss` (2 variables, 4,000 training rows), and `nonlin_simpson` (4 variables, 2,000 rows).
- Two methods (DECI-G and DECI-S) × five training seeds = 40 runs.
- Each dataset has one fixed training set. The five seeds vary model initialization and mini-batch order; they are not five independent datasets.

## Metrics

The table reports adjacency/skeleton F1, orientation F1, posterior mass on the exact true graph, and ATE RMSE. Causica's ATE RMSE uses standardized units; raw-unit values are also written to `per_run.csv`. Cells in the published-comparison table are medians over the five training seeds; mean and standard deviation are in `table5_mean_sd.csv`.

## Environment

Python 3.10 and Causica 0.4.6 are required for DECI (`requirements/deci-py310.txt`). Dataset validation and aggregation need NumPy and pandas.

## Run order

```bash
# Validate CSuite data (this writes/refreshes config.json files)
python src/e4_e5/check_csuite_data.py --data data/E45

# Optional smoke test: one dataset, one seed
python src/e4_e5/train_deci_csuite.py --variant deci_g --only nonlingauss --seeds 0 --results results/E45_smoke --progress
python src/e4_e5/aggregate_e45.py --data data/E45 --results results/E45_smoke --out results/E45_smoke/summary

# Full runs
python src/e4_e5/train_deci_csuite.py --variant deci_g --progress
python src/e4_e5/train_deci_csuite.py --variant deci_s --progress

# Table 5 and supporting CSVs
python src/e4_e5/aggregate_e45.py --data data/E45 --results results/E45 --out results/E45/summary
```

For a single dataset/seed, use `--only linexp --seeds 2`. The `nonlingauss` smoke test should show `convention check: OK` and `converged=True`; the linear-Gaussian `lingauss` case intentionally does not use the same direction-convention check.

## Report notes

Causica 0.4.6 is a rewrite of the code behind the published values. Treat the published median as a sanity check rather than expecting exact numerical reproduction. Record any differences in sample count, graph samples, and data scaling. The default sparsity setting matches E1; use `--sparsity-lambda 5 --results results/E45_lambda5` for the alternate lambda setting.

## Files

| File | Purpose |
|---|---|
| `check_csuite_data.py` | Data validation, true ATEs, and config files |
| `metrics.py` | Graph metrics (same implementation as E1) |
| `train_deci_csuite.py` | DECI-S / DECI-G training and ATE evaluation |
| `aggregate_e45.py` | Table 5 and supporting CSVs |

Original validation snapshots are preserved in [`docs/validation/e4_e5/`](../../docs/validation/e4_e5/).
