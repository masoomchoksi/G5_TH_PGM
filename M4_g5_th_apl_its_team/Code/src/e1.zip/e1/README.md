# E1 — Sample-size experiment (CSE 516 M2, Table 4)

This folder contains the E1 implementation. Run every command from the **repository root** (`Code/`).

## Experiment design

- 5 seeds × 5 methods: DECI-S, DECI-G, NOTEARS-MLP, PC, and ICALiNGAM.
- 25 datasets: ER(16, 16), nonlinear additive-noise model with non-Gaussian warped noise; seeds 0–4 and training sizes 250, 500, 1,000, 2,500, and 5,000.
- Within each seed, training sets are nested prefixes of a shared 5,000-row sample. Test data and the true graph are shared across training sizes. The resulting estimates across sizes are therefore correlated.

## Environment

DECI requires Python 3.10 and Causica 0.4.6. Install `requirements/deci-py310.txt`.
The classical baselines use the analysis environment in `requirements/analysis.txt`.

## Run order

```bash
# Validate the bundled datasets (does not regenerate them)
python src/e1/data_generation.py --out data --validate-only

# Classical baselines (analysis environment)
python src/e1/baselines.py --methods pc icalingam notears_mlp --data data/E1 --out results/E1

# DECI-S and DECI-G (Python 3.10 / Causica environment)
python src/e1/train_deci.py --variant deci_s --data data/E1 --results results/E1 --progress
python src/e1/train_deci.py --variant deci_g --data data/E1 --results results/E1 --progress

# Score DECI posterior samples
python src/e1/deci_interface.py --variant deci_s --data data/E1 --results results/E1
python src/e1/deci_interface.py --variant deci_g --data data/E1 --results results/E1

# Generate the table and plot
python src/e1/aggregate_e1.py --results results/E1 --out results/E1/summary
```

To run one dataset only, append `--only er16_16_n250_seed0` to the relevant training command. Dataset names follow `er16_16_n{250,500,1000,2500,5000}_seed{0-4}`. Completed runs are skipped on restart.

## Files

| File | Purpose |
|---|---|
| `data_generation.py` | Generate and validate E1 datasets |
| `metrics.py` | Graph metrics, including SHD and F1 |
| `baselines.py` | PC, ICALiNGAM, and NOTEARS-MLP |
| `train_deci.py` | DECI-S / DECI-G training |
| `deci_interface.py` | Score DECI posterior graph samples |
| `aggregate_e1.py` | Table 4, plots, and log-log slope |

See the project-level [`README.md`](../../README.md) for the repository structure and environment setup.
