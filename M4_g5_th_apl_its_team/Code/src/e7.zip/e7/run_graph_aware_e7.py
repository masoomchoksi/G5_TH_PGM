"""
run_graph_aware_e7.py - M3: graph-aware imputation for DECI on the frozen E7 data (two-stage prototype).

    STAGE 1  graphs: sampled from the BASELINE run's posterior (results/<..>/<variant>_baseline/<name>/posterior_samples.npy,
             already produced by train_deci_missing.py; nothing is retrained for this stage).
    IMPUTE   Markov-blanket conditional imputer (graph_aware_imputer.py) -> completed data (observed cells untouched).
    STAGE 2  DECI refit on the completed data with train_deci.train_one = the unchanged E1/E2 code path,
             same variant, lambda_s, batch size and step cap as the baseline.

Data safety: data/E7 is only READ. All outputs go under --results. The checksum of data/E7 is verified before and after.

    python run_graph_aware_e7.py --variant deci_g --method graphaware --impute-only      # minutes: imputation quality only
    python run_graph_aware_e7.py --variant deci_g --method graphaware --progress         # full: imputation + DECI refit

Methods (single lowercase token; it becomes the folder suffix and the 'method' column in score_e7.py):
    graphaware   Markov blanket under graphs sampled from the baseline posterior       (the proposal)
    agnosticmlp  same network/sweeps but conditioning on ALL variables                 (control: is it the graph or the imputer?)
    oraclegraph  Markov blanket in the TRUE graph                                      (diagnostic only, never the fair comparison)
Add --stochastic to sample instead of using the conditional mean (tag gets 'stoch'). Use --tag to name ablations,
e.g. --n-graphs 1 --tag graphawaren1  (tag must contain no underscore: score_e7.py splits the folder name at the last '_').
"""
import torch  # noqa: F401  MUST stay first (see train_deci.py)
import os
os.environ["MPLBACKEND"] = "Agg"
import argparse
import glob
import json
import shutil
import subprocess
import sys
import time
import traceback

import numpy as np
import pandas as pd

from graph_aware_imputer import graph_aware_impute, imputation_metrics, observed_stats, select_graphs

METHODS = ("graphaware", "agnosticmlp", "oraclegraph")


def verify_data(data_dir):
    if os.path.exists(os.path.join(data_dir, "MANIFEST_E7.sha256")):
        checksum_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "checksum_data.py")
        r = subprocess.run([sys.executable, checksum_script, "--verify", data_dir], capture_output=True, text=True)
        print("  data check:", r.stdout.strip())
        if r.returncode != 0:
            raise SystemExit("STOP: the frozen E7 data differ from the manifest. Re-upload the zip.")


def run_one(folder, variant, method, tag, results, args, train_fn=None):
    name = os.path.basename(folder)
    cfg = json.load(open(os.path.join(folder, "config.json")))
    seed = int(cfg["seed"])
    df = pd.read_csv(os.path.join(folder, "train.csv"))
    full = pd.read_csv(os.path.join(folder, "train_full.csv"))
    true = np.loadtxt(os.path.join(folder, "adj_matrix.csv"), delimiter=",", ndmin=2).astype(int)
    base_dir = os.path.join(results, f"{variant}_baseline", name)
    out_dir = os.path.join(results, f"{variant}_{tag}", name)
    comp_dir = os.path.join(results, "_completed", f"{variant}_{tag}", name)
    has_missing = bool(df.isna().values.any())
    blog_path = os.path.join(base_dir, "training_log.json")
    blog = json.load(open(blog_path)) if os.path.exists(blog_path) else {}

    # ---- 0 % missing: the completed data ARE the original data, so the refit would be an identical rerun
    if not has_missing:
        assert (df.values == full.values).all(), "0% dataset: train.csv != train_full.csv"
        if args.impute_only:
            return "skipped (0% missing: nothing to impute)"
        if args.rerun_zero:                                      # optional real rerun through the same path
            os.makedirs(comp_dir, exist_ok=True)
            for f in ("train.csv", "config.json", "adj_matrix.csv"):
                shutil.copy(os.path.join(folder, f), comp_dir)
            graphs, log = train_fn(comp_dir, variant, out_dir, args.batch_size, args.max_steps, args.sparsity_lambda,
                                   progress=args.progress)
            log.update(method=tag, imputer="none (0% missing, rerun)", missing_rate=0, regime=cfg.get("regime"))
        else:
            if not os.path.exists(os.path.join(base_dir, "posterior_samples.npy")):
                raise FileNotFoundError(f"baseline missing: {base_dir}")
            os.makedirs(out_dir, exist_ok=True)
            shutil.copy(os.path.join(base_dir, "posterior_samples.npy"), out_dir)
            log = dict(blog)
            log.update(method=tag, imputer="none (0% missing: baseline result reused; data identical)",
                       reused_baseline=True, missing_rate=0, regime=cfg.get("regime"))
        json.dump(log, open(os.path.join(out_dir, "training_log.json"), "w"), indent=2)
        return "0% missing: baseline reused" if not args.rerun_zero else "0% missing: rerun done"

    # ---- stage 1: graphs
    stage1_s = 0.0
    if method == "graphaware":
        sp = os.path.join(base_dir, "posterior_samples.npy")
        if not os.path.exists(sp):
            raise FileNotFoundError(f"stage 1 needs the baseline posterior samples: {sp}")
        graphs = select_graphs(np.load(sp), args.n_graphs, seed)
        stage1_s = float(blog.get("runtime_s") or 0.0)
        stage1_shd = None
    elif method == "oraclegraph":
        graphs = np.stack([true])
    else:
        graphs = None
    # ---- imputation
    t0 = time.time()
    res = graph_aware_impute(df, method, graphs, seed=seed, sweeps=args.sweeps, stochastic=args.stochastic,
                             hidden=args.hidden)
    impute_s = time.time() - t0
    mean, std = observed_stats(df.to_numpy(dtype=np.float64))
    z_true = (full.to_numpy(dtype=np.float64) - mean) / std
    m = imputation_metrics(res["z_hat"], z_true, res["mask"])
    # ---- never touch the original: write the completed data under results/ and re-check the invariants.
    # Observed cells are copied as the ORIGINAL TEXT from train.csv (so DECI's reader parses exactly the same
    # numbers as for the baseline); only the empty cells receive the imputed values.
    os.makedirs(comp_dir, exist_ok=True)
    raw = pd.read_csv(os.path.join(folder, "train.csv"), dtype=str, keep_default_na=False)
    obs = ~df.isna().values
    for (i, j) in zip(*np.nonzero(~obs)):
        assert raw.iat[i, j] == "", "a cell is NaN but its text is not empty"
        raw.iat[i, j] = repr(float(res["x_hat"][i, j]))
    raw.to_csv(os.path.join(comp_dir, "train.csv"), index=False)
    for f in ("config.json", "adj_matrix.csv"):
        shutil.copy(os.path.join(folder, f), comp_dir)
    back = pd.read_csv(os.path.join(comp_dir, "train.csv")).to_numpy()
    assert np.array_equal(back[obs], df.to_numpy()[obs]), "observed entries changed"
    assert not np.isnan(back).any(), "completed data still contain NaN"
    report = dict(method=tag, variant=variant, dataset=name, seed=seed, missing_rate=cfg.get("missing_rate"),
                  regime=cfg.get("regime"), n_graphs_used=0 if graphs is None else int(len(graphs)),
                  sweeps=args.sweeps, stochastic=args.stochastic, impute_s=round(impute_s, 1),
                  stage1_runtime_s=stage1_s, sweep_changes=res["sweep_changes"], **m)
    json.dump(report, open(os.path.join(comp_dir, "imputation_report.json"), "w"), indent=2)
    msg = (f"impute_rmse={m['impute_rmse']:.3f} mae={m['impute_mae']:.3f} (mean-fill {m['impute_rmse_mean_fill']:.3f}) "
           f"[baseline {blog.get('impute_rmse', float('nan')):.3f}] {impute_s:.0f}s")
    if args.impute_only:
        return msg

    # ---- stage 2: refit DECI on the completed data (same code path as E1/E2)
    t1 = time.time()
    _, log = train_fn(comp_dir, variant, out_dir, args.batch_size, args.max_steps, args.sparsity_lambda,
                      progress=args.progress)
    refit_s = time.time() - t1
    log.update(method=tag, imputer=f"{method} (stage 1 graphs: {report['n_graphs_used']}, sweeps {args.sweeps}"
                                   f"{', stochastic' if args.stochastic else ''})",
               missing_rate=cfg.get("missing_rate"), regime=cfg.get("regime"),
               impute_rmse=m["impute_rmse"], impute_mae=m["impute_mae"], impute_rmse_mean_fill=m["impute_rmse_mean_fill"],
               impute_nll=None, n_missing=m["n_missing"], refit_runtime_s=round(refit_s, 1),
               impute_runtime_s=round(impute_s, 1), stage1_runtime_s=stage1_s,
               runtime_s=round(stage1_s + impute_s + refit_s, 1),   # TOTAL cost of the method, split above
               sweep_changes=res["sweep_changes"])
    json.dump(log, open(os.path.join(out_dir, "training_log.json"), "w"), indent=2)
    return msg + f" | refit {refit_s / 60:.1f} min converged={log.get('converged')}"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--variant", required=True, choices=["deci_s", "deci_g"])
    p.add_argument("--method", default="graphaware", choices=METHODS)
    p.add_argument("--tag", default=None, help="folder/method name (no underscore). default: method [+ 'stoch']")
    p.add_argument("--data", default="data/E7")
    p.add_argument("--results", default="results/E7_lambda5")
    p.add_argument("--only", nargs="*", default=None)
    p.add_argument("--n-graphs", type=int, default=5, help="posterior graph samples aggregated (graphaware only)")
    p.add_argument("--sweeps", type=int, default=5)
    p.add_argument("--hidden", type=int, default=64)
    p.add_argument("--stochastic", action="store_true")
    p.add_argument("--impute-only", action="store_true", help="imputation + its RMSE only; no DECI refit (minutes)")
    p.add_argument("--rerun-zero", action="store_true", help="really rerun DECI at 0% (default: reuse the baseline result)")
    p.add_argument("--batch-size", type=int, default=512)
    p.add_argument("--max-steps", type=int, default=400_000)
    p.add_argument("--sparsity-lambda", type=float, default=None, help="default: the baseline run's logged value")
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--progress", action="store_true")
    args = p.parse_args()

    tag = args.tag or (args.method + ("stoch" if args.stochastic else ""))
    if not tag.isalnum():
        raise SystemExit("--tag must be letters/digits only (score_e7.py splits folder names at the last underscore)")
    if os.path.realpath(args.results).startswith(os.path.realpath(args.data)):
        raise SystemExit("--results must not be inside --data")
    verify_data(args.data)

    train_fn = None
    if not args.impute_only:
        from train_deci import train_one
        train_fn = train_one

    folders = sorted(glob.glob(os.path.join(args.data, "*")))
    if args.only:
        folders = [f for f in folders if os.path.basename(f) in set(args.only)]
    for folder in folders:
        name = os.path.basename(folder)
        out_dir = os.path.join(args.results, f"{args.variant}_{tag}", name)
        done = (os.path.join(args.results, "_completed", f"{args.variant}_{tag}", name, "imputation_report.json")
                if args.impute_only else os.path.join(out_dir, "posterior_samples.npy"))
        if os.path.exists(done) and not args.overwrite:
            print(f"[{args.variant}/{tag}] {name}: exists, skipping")
            continue
        try:
            if args.sparsity_lambda is None and not args.impute_only:
                bl = os.path.join(args.results, f"{args.variant}_baseline", name, "training_log.json")
                args.sparsity_lambda = json.load(open(bl)).get("prior_sparsity_lambda") if os.path.exists(bl) else None
                if args.sparsity_lambda is None:
                    raise FileNotFoundError(f"cannot read lambda_s from {bl}; pass --sparsity-lambda 5")
                print(f"  using lambda_s={args.sparsity_lambda} from the baseline log")
            print(f"[{args.variant}/{tag}] {name}: {run_one(folder, args.variant, args.method, tag, args.results, args, train_fn)}")
        except Exception as exc:
            traceback.print_exc()
            os.makedirs(out_dir, exist_ok=True)
            with open(os.path.join(out_dir, "error.txt"), "w") as f:
                f.write(f"{type(exc).__name__}: {exc}\n")
            print(f"[{args.variant}/{tag}] {name}: FAILED ({type(exc).__name__})")
    verify_data(args.data)


if __name__ == "__main__":
    main()
