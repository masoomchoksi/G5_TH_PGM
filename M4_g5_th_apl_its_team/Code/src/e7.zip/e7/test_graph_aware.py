"""
test_graph_aware.py - fast unit tests (about 20 s, CPU, no Causica needed). Run before the real experiment:
    python test_graph_aware.py
"""
import os
import subprocess
import sys
import tempfile

import numpy as np
import pandas as pd

from graph_aware_imputer import graph_aware_impute, imputation_metrics, observed_stats, select_graphs
from markov_blanket import all_markov_blankets, markov_blanket

ok = lambda msg: print("PASS", msg)


def adj(d, edges):
    A = np.zeros((d, d), int)
    for a, b in edges:
        A[a, b] = 1                                      # a -> b, adj[j, i] = 1 means j -> i
    return A


# 1-3: Markov blanket on hand-written DAGs (guide examples; 0-indexed: X1->X3, X3->X4, X2->X4)
G = adj(4, [(0, 2), (2, 3), (1, 3)])
assert markov_blanket(G, 2) == [0, 1, 3]; ok("MB(X3) = {X1, X2, X4}")
G2 = adj(3, [(0, 1), (1, 2)])
assert markov_blanket(G2, 1) == [0, 2]; ok("chain: MB(X2) = {X1, X3}")
assert all(j not in mb for j, mb in enumerate(all_markov_blankets(G))); ok("no variable is in its own blanket")
Gd = adj(4, [(0, 3), (1, 3), (2, 3), (0, 1)])
assert markov_blanket(Gd, 0) == [1, 2, 3] and len(set(markov_blanket(Gd, 0))) == 3; ok("co-parents and duplicates handled")
try:
    markov_blanket(np.zeros((3, 4)), 0); raise SystemExit("FAIL bad shape accepted")
except ValueError:
    ok("non-square adjacency rejected")
try:
    select_graphs(np.zeros((5, 3, 4)), 1, 0); raise SystemExit("FAIL bad samples accepted")
except ValueError:
    ok("posterior samples with a bad shape rejected")

# synthetic nonlinear chain X0 -> X1 -> X2 -> X3, 700 rows, 30 % MCAR
rng = np.random.default_rng(0)
N = 700
x0 = rng.normal(size=N); x1 = np.tanh(2 * x0) + 0.3 * rng.normal(size=N)
x2 = x1 ** 2 + 0.3 * rng.normal(size=N); x3 = np.sin(2 * x2) + 0.3 * rng.normal(size=N)
full = pd.DataFrame(np.c_[x0, x1, x2, x3], columns=list("abcd"))
mask = rng.random(full.shape) > 0.3
miss = full.where(mask)
chain = adj(4, [(0, 1), (1, 2), (2, 3)])

# 4-5: observed cells never overwritten; no missing cells left
r = graph_aware_impute(miss, "oraclegraph", np.stack([chain]), seed=0, sweeps=3)
assert np.array_equal(r["x_hat"][mask], full.to_numpy()[mask]); ok("observed entries never overwritten (exact)")
assert not np.isnan(r["x_hat"]).any(); ok("completed matrix has no NaN (missing blanket members handled by sweeps)")
assert r["sweep_changes"][-1] < r["sweep_changes"][0]; ok("imputation converges: changes per sweep shrink %s" % np.round(r["sweep_changes"], 3))

# 6: imputation error uses hidden cells only and beats mean-fill with the right graph
mean, std = observed_stats(miss.to_numpy())
z_true = (full.to_numpy() - mean) / std
m = imputation_metrics(r["z_hat"], z_true, r["mask"])
manual = np.sqrt(np.mean((r["z_hat"][~mask] - z_true[~mask]) ** 2))
assert abs(m["impute_rmse"] - manual) < 1e-9 and m["n_missing"] == int((~mask).sum()); ok("RMSE computed on hidden cells only")
assert m["impute_rmse"] < 0.8 * m["impute_rmse_mean_fill"]; ok("oracle-graph imputer clearly beats mean-fill (%.3f vs %.3f)" % (m["impute_rmse"], m["impute_rmse_mean_fill"]))

# 7: no missing cells -> returned unchanged; fully missing column -> no crash
r0 = graph_aware_impute(full, "oraclegraph", np.stack([chain]), seed=0, sweeps=2)
assert np.array_equal(r0["x_hat"], full.to_numpy()); ok("0% missing returns the data exactly")
bad = miss.copy(); bad["d"] = np.nan
rb = graph_aware_impute(bad, "oraclegraph", np.stack([chain]), seed=0, sweeps=2)
assert not np.isnan(rb["x_hat"][:, :3]).any(); ok("a 100 %-missing target column does not crash")

# 8: the frozen data are untouched (only if the manifest is present)
if os.path.exists("data/E7/MANIFEST_E7.sha256"):
    checksum_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), "checksum_data.py")
    out = subprocess.run([sys.executable, checksum_script, "--verify", "data/E7"], capture_output=True, text=True)
    assert out.returncode == 0, out.stdout; ok(out.stdout.strip())
print("ALL TESTS PASSED")
