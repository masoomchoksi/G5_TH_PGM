"""
graph_aware_imputer.py - STAGE 2 of the M3 proposal: iterative conditional imputation of missing entries.

Each variable X_j with missing cells gets a small regression network trained on the rows where X_j is observed,
using as inputs only its CONTEXT variables (their observed values, or their current estimates when missing):
    graphaware  context = Markov blanket of X_j in a graph sampled from DECI's baseline posterior   (the proposal)
    agnosticmlp context = ALL other variables, same network, same sweeps                            (control)
    oraclegraph context = Markov blanket in the TRUE graph                                          (diagnostic only)
The loop is run for K sweeps. Observed entries are never changed. All work is in z-score units of the
OBSERVED entries (same convention as the baseline's imputation RMSE).
"""
import numpy as np
import torch
import torch.nn as nn

from markov_blanket import all_markov_blankets


# ---------------------------------------------------------------- data helpers
def observed_stats(arr: np.ndarray):
    """mean/std of each column from observed entries only (identical to deci_missing.standardise_with_mask)."""
    mean = np.nanmean(arr, axis=0)
    std = np.nanstd(arr, axis=0, ddof=1)
    std = np.where(std < 1e-12, 1.0, std)
    return mean, std


def select_graphs(samples: np.ndarray, n: int, seed: int, require_acyclic: bool = True) -> np.ndarray:
    """Pick n graphs from the (S, d, d) posterior samples, reproducibly. Prefers acyclic samples."""
    from metrics import has_cycle
    samples = (np.asarray(samples) > 0.5).astype(int)
    if samples.ndim != 3 or samples.shape[1] != samples.shape[2]:
        raise ValueError(f"posterior samples must have shape (S, d, d); got {samples.shape}")
    idx = np.arange(len(samples))
    if require_acyclic:
        ok = np.array([not has_cycle(g) for g in samples])
        if ok.any():
            idx = idx[ok]
        else:
            print("  warning: every posterior sample has a cycle; using cyclic samples")
    rng = np.random.default_rng(seed)
    pick = rng.choice(idx, size=min(n, len(idx)), replace=False)
    return samples[np.sort(pick)]


# ---------------------------------------------------------------- the conditional model
class _Reg(nn.Module):
    """MLP + linear skip: x -> scalar. The skip lets it represent the linear case exactly."""
    def __init__(self, k: int, hidden: int):
        super().__init__()
        self.mlp = nn.Sequential(nn.Linear(k, hidden), nn.LeakyReLU(), nn.Linear(hidden, hidden),
                                 nn.LeakyReLU(), nn.Linear(hidden, 1))
        self.skip = nn.Linear(k, 1)

    def forward(self, x):
        return (self.mlp(x) + self.skip(x)).squeeze(-1)


def _fit(model, X, y, tr, va, steps, lr, wd):
    """Full-batch Adam; keep the weights with the best validation loss (checked every 10 steps)."""
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=wd)
    best, best_state = float("inf"), None
    for s in range(steps):
        opt.zero_grad()
        loss = ((model(X[tr]) - y[tr]) ** 2).mean()
        loss.backward()
        opt.step()
        if s % 10 == 9 or s == steps - 1:
            with torch.no_grad():
                v = ((model(X[va]) - y[va]) ** 2).mean().item()
            if v < best:
                best, best_state = v, {k: t.clone() for k, t in model.state_dict().items()}
    model.load_state_dict(best_state)
    return best


def impute_z(z0: np.ndarray, mask: np.ndarray, contexts: list, seed: int, sweeps: int = 5,
             stochastic: bool = False, hidden: int = 32, steps_first: int = 150, steps_next: int = 50,
             lr: float = 5e-3, wd: float = 1e-2, use_mask: bool = False):
    """z0: (N, d) z-scores with 0 at missing cells; mask: (N, d) bool, True = observed; contexts[j]: list of columns.
    Returns (z_hat, mean_abs_change_per_sweep). Observed cells of z_hat equal z0 exactly."""
    N, d = z0.shape
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    z = z0.astype(np.float32).copy()
    models, splits, resid = {}, {}, {}
    targets = [j for j in range(d) if (~mask[:, j]).any()]
    changes = []
    for sweep in range(sweeps):
        delta, count = 0.0, 0
        for j in targets:
            miss, obs = ~mask[:, j], mask[:, j]
            ctx = list(contexts[j])
            if len(ctx) == 0 or obs.sum() < 10:
                new = np.zeros(miss.sum(), dtype=np.float32)     # no usable context: the observed mean (z = 0)
                if stochastic and obs.sum() > 1 and len(ctx) == 0:
                    new = new + rng.normal(0, z0[obs, j].std(), size=new.shape).astype(np.float32)
            else:
                Xc = z[:, ctx]
                if use_mask:                                      # optional (off: it overfit in our check)
                    Xc = np.concatenate([Xc, (~mask[:, ctx]).astype(np.float32)], axis=1)
                X = torch.as_tensor(Xc)
                y = torch.as_tensor(z0[:, j])
                if j not in models:
                    ids = rng.permutation(np.flatnonzero(obs))
                    nv = max(1, int(0.15 * len(ids)))
                    splits[j] = (torch.as_tensor(ids[nv:]), torch.as_tensor(ids[:nv]))
                    models[j] = _Reg(X.shape[1], hidden)
                tr, va = splits[j]
                vloss = _fit(models[j], X, y, tr, va, steps_first if sweep == 0 else steps_next, lr, wd)
                resid[j] = float(np.sqrt(max(vloss, 1e-8)))
                with torch.no_grad():
                    pred = models[j](X[torch.as_tensor(np.flatnonzero(miss))]).numpy()
                new = pred + (rng.normal(0, resid[j], size=pred.shape).astype(np.float32) if stochastic else 0.0)
            delta += float(np.abs(new - z[miss, j]).sum())
            count += int(miss.sum())
            z[miss, j] = new
        changes.append(delta / max(count, 1))
    z[mask] = z0[mask]                                           # observed entries are never overwritten
    return z, changes


def contexts_for(mode: str, graph, d: int) -> list:
    if mode == "agnosticmlp":
        return [[i for i in range(d) if i != j] for j in range(d)]
    return all_markov_blankets(graph)                            # graphaware (sampled graph) / oraclegraph (true graph)


def graph_aware_impute(df_missing, mode: str, graphs, seed: int, sweeps: int = 5, stochastic: bool = False, **kw):
    """df_missing: DataFrame with NaN. graphs: (G, d, d) array (ignored for 'agnosticmlp').
    Returns dict(x_hat (original units, observed entries untouched), z_hat, z0, mean, std, mask, sweep_changes)."""
    arr = df_missing.to_numpy(dtype=np.float64)
    mask = ~np.isnan(arr)
    mean, std = observed_stats(arr)
    z0 = np.where(mask, (arr - mean) / std, 0.0)
    d = arr.shape[1]
    if mode == "agnosticmlp":
        graphs = [None]
    outs, all_changes = [], []
    for g_i, g in enumerate(graphs):
        z_hat, ch = impute_z(z0, mask, contexts_for(mode, g, d), seed=seed + 1000 * g_i, sweeps=sweeps,
                             stochastic=stochastic, **kw)
        outs.append(z_hat)
        all_changes.append(ch)
    outs = np.stack(outs)
    if stochastic and len(outs) > 1:                             # each missing cell takes one graph's sample
        pick = np.random.default_rng(seed).integers(0, len(outs), size=z0.shape)
        z_hat = np.take_along_axis(outs, pick[None], axis=0)[0]
    else:
        z_hat = outs.mean(axis=0)                                # posterior aggregation over graph samples
    z_hat = np.where(mask, z0, z_hat)
    x_hat = np.where(mask, arr, z_hat * std + mean)              # observed cells: the ORIGINAL numbers, bit for bit
    return dict(x_hat=x_hat, z_hat=z_hat, z0=z0, mean=mean, std=std, mask=mask,
                sweep_changes=np.mean(all_changes, axis=0).tolist())


def imputation_metrics(z_hat: np.ndarray, z_true: np.ndarray, mask: np.ndarray) -> dict:
    """RMSE / MAE on the artificially hidden cells ONLY. Mean-fill = fill with the observed column mean (z = 0)."""
    miss = ~mask
    if not miss.any():
        return dict(impute_rmse=None, impute_mae=None, impute_rmse_mean_fill=None, impute_nll=None, n_missing=0)
    e = (z_hat - z_true)[miss]
    return dict(impute_rmse=float(np.sqrt(np.mean(e ** 2))), impute_mae=float(np.mean(np.abs(e))),
                impute_rmse_mean_fill=float(np.sqrt(np.mean(z_true[miss] ** 2))), impute_nll=None,
                n_missing=int(miss.sum()))
