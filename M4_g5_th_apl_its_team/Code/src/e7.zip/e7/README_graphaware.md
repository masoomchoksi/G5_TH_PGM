# E7 graph-aware imputation extension

This is the M3 graph-aware extension layered on top of the E7 baseline. The baseline code and frozen datasets are unchanged. Run all commands from the **repository root** (`Code/`).

## Methods

- `graphaware`: Markov-blanket conditional imputation using graphs sampled from the baseline posterior (proposed method).
- `agnosticmlp`: same imputer/sweeps but conditioned on all variables (control).
- `oraclegraph`: Markov blanket from the true graph (diagnostic only; not the fair comparison).

The Markov blanket contains a variable's parents, children, and co-parents of its children. The observed cells are copied unchanged. Results are written under `--results`; frozen `data/E7` is read-only. For 0% missingness, the baseline posterior is reused unless `--rerun-zero` is specified.

## Run order

First run the E7 baseline and generate its posterior samples (see [`README.md`](README.md)). Then run:

```bash
# Fast unit tests
python src/e7/test_graph_aware.py

# Optional imputation-only evaluation
python src/e7/run_graph_aware_e7.py --variant deci_g --method graphaware --impute-only

# Full imputation plus DECI refit
python src/e7/run_graph_aware_e7.py --variant deci_g --method graphaware --progress

# Score and compare against the baseline
python src/e7/score_e7.py --data data/E7 --results results/E7_lambda5
python src/e7/compare_e7_graphaware.py --results results/E7_lambda5 --out results/E7_lambda5/summary
```

Use `--method agnosticmlp` for the control or `--method oraclegraph` for the diagnostic. `--stochastic` samples imputed values instead of using the conditional mean. Use `--tag` for ablations; tags must not contain underscores. Runtime records stage 1 (baseline), imputation, and stage 2 (refit) separately.
