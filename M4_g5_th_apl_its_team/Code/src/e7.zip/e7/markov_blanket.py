"""
markov_blanket.py - Markov blankets from an adjacency matrix. Pure numpy, no Causica needed.

Convention (same as posterior_samples.npy, adj_matrix.csv and metrics.py): adj[j, i] = 1 means j -> i.
MB(X_j) = Pa(X_j) | Ch(X_j) | Pa(Ch(X_j)),  minus X_j itself.
Why this set: given its Markov blanket, X_j is conditionally independent of every other variable, so
p(x_j | all other variables) = p(x_j | MB(x_j)) when the graph is right.
"""
import numpy as np


def _binary(adj) -> np.ndarray:
    A = np.asarray(adj)
    if A.ndim != 2 or A.shape[0] != A.shape[1]:
        raise ValueError(f"adjacency matrix must be square (d, d); got shape {A.shape}")
    return (A > 0.5).astype(int)


def parents(adj, j: int) -> set:
    A = _binary(adj)
    return {int(i) for i in np.flatnonzero(A[:, j])} - {j}


def children(adj, j: int) -> set:
    A = _binary(adj)
    return {int(i) for i in np.flatnonzero(A[j, :])} - {j}


def markov_blanket(adj, j: int) -> list:
    A = _binary(adj)
    if not 0 <= j < A.shape[0]:
        raise IndexError(f"variable {j} out of range for d={A.shape[0]}")
    ch = children(A, j)
    co_parents = set()
    for c in ch:
        co_parents |= parents(A, c)
    return sorted((parents(A, j) | ch | co_parents) - {j})   # a set: no duplicates; self removed


def all_markov_blankets(adj) -> list:
    A = _binary(adj)
    return [markov_blanket(A, j) for j in range(A.shape[0])]
