# E7 — Missing-data DECI baseline (CSE 516 M2, Table 6 / P5)

This folder contains the baseline re-implementation of DECI's graph-agnostic amortized imputation in Causica 0.4.6. The graph-aware extension is documented separately in [`README_graphaware.md`](README_graphaware.md). Run commands from the **repository root** (`Code/`).

## Dataset grid

The frozen E7 data contain 24 datasets: two regimes (`nonlinear` and `lingauss`) × four MCAR missing rates (0%, 10%, 30%, 50%) × three seeds. Do **not** regenerate the frozen datasets for a normal run. `train_full.csv` contains complete training values; `train.csv` contains the masked observations.

## Environment and implementation notes

Use Python 3.10 with Causica 0.4.6 (`requirements/deci-py310.txt`). The imputer receives `[x * mask, mask]`, predicts an independent Gaussian per variable, and fills missing cells with reparameterized samples. The imputer is graph-agnostic. The implementation retains the reconstruction regularizer and adds the imputation entropy to the ELBO. Its optimizer has a separate learning-rate setting (`--imputer-lr`, default 1e-3); report this value.

## Run order

```bash
# Verify the frozen data before running anything
python src/e7/checksum_data.py --verify data/E7

# Validate the shipped data without regenerating it
python src/e7/make_e7_data.py --out data --validate-only

# Fast module self-check, then a one-dataset pilot
python src/e7/check_e7_module.py data/E7/er16_16_n1000_nonlinear_seed0_miss30
python src/e7/train_deci_missing.py --variant deci_g --data data/E7 --results results/E7_lambda5 --sparsity-lambda 5 --progress --only er16_16_n1000_nonlinear_seed0_miss30

# Score and aggregate
python src/e7/score_e7.py --data data/E7 --results results/E7_lambda5
python src/e7/aggregate_e7.py --results results/E7_lambda5 --out results/E7_lambda5/summary --ref-results results/E1_lambda5 --ref-data data/E1
```

The grid is 2 regimes × 4 missing rates × 3 seeds = 24 DECI-G runs. The final two aggregation flags are optional and add the P5 comparison against E1 results. The nonlinear 0%-missing datasets should reproduce the corresponding E1 runs, subject to normal hardware nondeterminism.

## Tests and limitations

- `test_imputer_math.py` checks the imputer ELBO against a known Gaussian conditional and verifies that observed entries are not changed.
- `check_e7_module.py` checks module setup and one training step.
- Only continuous variables and MCAR missingness are supported. The Gaussian imputation family may not represent the true conditional distribution for nonlinear data.
- The datasets contain no interventions, so E7 does not report an ATE column.

## Files

| File | Purpose |
|---|---|
| `checksum_data.py` | Verify the frozen dataset manifest |
| `make_e7_data.py`, `data_generation.py` | E7 dataset preparation and shared generator |
| `deci_missing.py` | Missing-data module and imputer |
| `train_deci_missing.py` | DECI missing-data runner |
| `score_e7.py`, `aggregate_e7.py` | Per-run metrics, Table 6, and P5 check |
| `test_imputer_math.py`, `check_e7_module.py` | Baseline tests |
| `run_graph_aware_e7.py`, `graph_aware_imputer.py` | Graph-aware extension |
| `compare_e7_graphaware.py`, `test_graph_aware.py`, `markov_blanket.py` | Graph-aware comparison, tests, and graph utilities |
| `notebooks/CSE516_M7_baseline.ipynb` | Baseline notebook |
