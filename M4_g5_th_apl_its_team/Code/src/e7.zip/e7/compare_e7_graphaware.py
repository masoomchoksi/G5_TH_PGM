"""
compare_e7_graphaware.py - paired comparison of every method against the baseline (same dataset, same seed).

    python score_e7.py --data data/E7 --results results/E7_lambda5          # first: builds e7_per_run.csv
    python compare_e7_graphaware.py --results results/E7_lambda5 --out results/E7_lambda5/summary

Writes  e7_paired_vs_baseline.csv   per (variant, regime, rate, method): mean paired difference (method - baseline) of
                                    SHD / adj F1 / orient F1 / imputation RMSE, SD, 95 % t-CI, Cohen dz, Wilcoxon p (only n >= 6)
        e7_imputation_only.csv      imputation RMSE/MAE per (variant, regime, rate, method) from the saved imputation reports
                                    (works without any DECI refit) next to the baseline imputer's RMSE
        e7_error_analysis.csv       per run: baseline SHD (the stage-1 graph quality) vs the change in SHD
Negative SHD / RMSE differences and positive F1 differences mean the method is better than the baseline.
With 3 seeds the CIs are wide: read the effect sizes, not the p-values.
"""
import argparse
import glob
import json
import os

import numpy as np
import pandas as pd
from scipy import stats

KEYS = ["expected_shd", "expected_adj_f1", "expected_orient_f1", "impute_rmse"]


def paired(diff: np.ndarray) -> dict:
    n = len(diff)
    out = dict(n_pairs=n, mean_diff=float(diff.mean()))
    if n > 1:
        sd = float(diff.std(ddof=1))
        h = float(stats.t.ppf(0.975, n - 1) * sd / np.sqrt(n))
        out.update(sd_diff=sd, ci95_low=float(diff.mean() - h), ci95_high=float(diff.mean() + h),
                   cohen_dz=float(diff.mean() / sd) if sd > 0 else float("nan"),
                   wilcoxon_p=float(stats.wilcoxon(diff).pvalue) if n >= 6 and np.any(diff != 0) else float("nan"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results/E7_lambda5")
    ap.add_argument("--out", default="results/E7_lambda5/summary")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    per_run_csv = os.path.join(a.results, "e7_per_run.csv")
    if os.path.exists(per_run_csv):
        pr = pd.read_csv(per_run_csv)
        pr = pr[pr.status == "ok"]
    else:                                   # imputation-only stage: run score_e7.py later for the graph metrics
        print("note: e7_per_run.csv not found (run score_e7.py first for graph-metric comparisons); imputation table only")
        pr = pd.DataFrame(columns=["status", "method", "variant", "regime", "missing_rate", "seed"])
    base = pr[pr.method == "baseline"]
    rows, err = [], []
    for (variant, regime, rate, method), g in pr[pr.method != "baseline"].groupby(["variant", "regime", "missing_rate", "method"]):
        b = base[(base.variant == variant) & (base.regime == regime) & (base.missing_rate == rate)]
        m = g.merge(b, on="seed", suffixes=("", "_base"))
        if m.empty:
            continue
        row = dict(variant=variant, regime=regime, missing_rate=rate, method=method)
        for k in KEYS:
            if k in m and f"{k}_base" in m and m[k].notna().all() and m[f"{k}_base"].notna().all():
                row.update({f"{k}__{kk}": v for kk, v in paired((m[k] - m[f"{k}_base"]).to_numpy()).items()})
        rows.append(row)
        for _, r in m.iterrows():
            err.append(dict(variant=variant, regime=regime, missing_rate=rate, method=method, seed=r.seed,
                            stage1_baseline_shd=r.expected_shd_base, method_shd=r.expected_shd,
                            delta_shd=r.expected_shd - r.expected_shd_base))
    pd.DataFrame(rows).to_csv(os.path.join(a.out, "e7_paired_vs_baseline.csv"), index=False)
    pd.DataFrame(err).to_csv(os.path.join(a.out, "e7_error_analysis.csv"), index=False)

    imp = []
    for p in glob.glob(os.path.join(a.results, "_completed", "*", "*", "imputation_report.json")):
        r = json.load(open(p))
        bl = os.path.join(a.results, f"{r['variant']}_baseline", r["dataset"], "training_log.json")
        r["baseline_impute_rmse"] = json.load(open(bl)).get("impute_rmse") if os.path.exists(bl) else None
        imp.append(r)
    if imp:
        di = pd.DataFrame(imp)
        t = (di.groupby(["variant", "regime", "missing_rate", "method"])
               .agg(rmse=("impute_rmse", "mean"), rmse_sd=("impute_rmse", "std"), mae=("impute_mae", "mean"),
                    mean_fill=("impute_rmse_mean_fill", "mean"), baseline_rmse=("baseline_impute_rmse", "mean"),
                    impute_s=("impute_s", "mean"), runs=("seed", "count")).reset_index())
        t.to_csv(os.path.join(a.out, "e7_imputation_only.csv"), index=False)
        print("\nImputation quality (z-score units; lower is better):\n" + t.round(3).to_string(index=False))
    if rows:
        print("\nPaired difference vs baseline (method - baseline):")
        cols = ["variant", "regime", "missing_rate", "method"] + [c for c in pd.DataFrame(rows).columns if c.endswith("__mean_diff") or c.endswith("__cohen_dz")]
        print(pd.DataFrame(rows)[cols].round(3).to_string(index=False))
    print(f"\n-> {a.out}")


if __name__ == "__main__":
    main()
