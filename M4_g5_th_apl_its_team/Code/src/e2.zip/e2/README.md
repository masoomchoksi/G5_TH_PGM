# E2 — Graph-size and cyclic-sample experiment (CSE 516 M2, Table 7)

This folder contains the E2 implementation. Run every command from the **repository root** (`Code/`).

## Experiment design

- Table 7a: DECI-G on ER(D, D), D = 8, 12, 16, 20, 24, 32, with seeds 0–2 (18 runs).
- Table 7b: DECI-S validation on D = 8 and 24, with seeds 0–1 (4 runs).
- Training size is 1,000. The model uses the same nonlinear additive-noise family as E1, with a different random DAG for each graph-size/seed pair.
- One hundred hard graph samples are drawn from the learned posterior. Cyclic-sample rate and shortest directed-cycle length are reported; cyclic samples remain included in expected SHD/F1.

## Environment

DECI requires Python 3.10 and Causica 0.4.6 (`requirements/deci-py310.txt`). Scoring and aggregation use the analysis dependencies (`requirements/analysis.txt`).

## Run order

```bash
# Validate bundled datasets
python src/e2/data_generation.py --out data --validate-only

# Main DECI-G arm
python src/e2/train_deci.py --variant deci_g --data data/E2 --results results/E2_lambda5 --sparsity-lambda 5 --progress

# DECI-S validation arm (D=8 and D=24, seeds 0 and 1)
python src/e2/train_deci.py --variant deci_s --data data/E2 --results results/E2_lambda5 --sparsity-lambda 5 --progress --only er8_8_n1000_seed0 er8_8_n1000_seed1 er24_24_n1000_seed0 er24_24_n1000_seed1

# Per-run scores, summary tables, trend test, and plot
python src/e2/score_e2.py --data data/E2 --results results/E2_lambda5
python src/e2/aggregate_e2.py --results results/E2_lambda5 --out results/E2_lambda5/summary
```

To run a subset of the DECI-G grid, use `--only` followed by names such as `er8_8_n1000_seed0` or `er32_32_n1000_seed2`. Completed runs are skipped on restart.

## Report notes

- ER(16,16), n=1,000, seeds 0–2 are shared with E1. They can be reused only when the matching E1 DECI-G results use the same configuration.
- Report the training size assumption (1,000), the hardware used for runtime measurements, and incomplete/non-converged rows.
- The cyclic-rate trend is tested by regression in `p6_trend.csv`; do not infer it only from the plot.

## Files

| File | Purpose |
|---|---|
| `data_generation.py` | E2 dataset generation and validation |
| `metrics.py` | SHD, F1, cyclic rate, and shortest cycle |
| `train_deci.py`, `deci_interface.py` | DECI training and posterior interface |
| `score_e2.py` | Per-run KPIs |
| `aggregate_e2.py` | Table 7a/7b, P6 trend, and plots |
