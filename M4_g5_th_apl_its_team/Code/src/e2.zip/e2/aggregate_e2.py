"""
aggregate_e2.py - builds Table 7a / 7b (E2: graph size D and cyclic-sample rate, tests P6).

Usage (after score_e2.py):
    python aggregate_e2.py --results results/E2_lambda5 --out results/E2_lambda5/summary

Outputs (in --out)
    table7a.csv / .md / .png     DECI-G main arm,       rows D (edges) = 8, 12, 16, 20, 24, 32
    table7b.csv / .md / .png     DECI-S validation arm, rows D (edges) = 8, 24
    table7_counts.csv            runs per cell: ok / failed / missing, and how many converged
    p6_trend.csv                 slope of the cyclic-sample rate on D with a 95% CI (t distribution)
    e2_vs_D.png                  cyclic-sample rate and expected SHD against D (mean +/- SD bands)

Columns (as in the report's Table 7)
    Expected SHD, Adj. F1, Cyclic-sample rate : mean +/- sample SD (n-1) over seeds
    Shortest cycle (median)                   : median of the shortest-cycle length over ALL cyclic
                                                samples of ALL seeds of that row ("none cyclic" if 0)
    Runtime (h)                               : mean +/- SD of training wall-clock hours

Rules from the report
    * A cell with no successful run prints "Not run", never silently dropped.
    * The P6 trend is a regression slope with a CI, not read off a plot.
    * Rows whose seeds did not all converge are flagged in table7_counts.csv; state this in the caption.
"""

import os
os.environ["MPLBACKEND"] = "Agg"          # file backend (Colab/Kaggle notebooks set a notebook-only one)
import argparse

import numpy as np
import pandas as pd
from scipy import stats

G_DS_DEFAULT = [8, 12, 16, 20, 24, 32]
S_DS_DEFAULT = [8, 24]
COLUMNS = ["Expected SHD", "Adj. F1", "Cyclic-sample rate", "Shortest cycle (median)", "Runtime (h)"]


def _mean_sd(x: pd.Series, decimals: int) -> str:
    x = x.dropna()
    if len(x) == 0:
        return "n/a"
    if len(x) == 1:
        return f"{x.iloc[0]:.{decimals}f} (1 seed)"
    return f"{x.mean():.{decimals}f} ± {x.std(ddof=1):.{decimals}f}"


def _pooled_median(sub: pd.DataFrame) -> str:
    lengths = []
    for s in sub["cycle_lengths"].fillna("").astype(str):
        lengths += [int(v) for v in s.split() if v]
    if not lengths:
        return "none cyclic"
    med = float(np.median(lengths))
    return f"{med:.0f}" if med == int(med) else f"{med:.1f}"


def build_table(df: pd.DataFrame, variant: str, ds):
    ok = df[(df["variant"] == variant) & (df["status"] == "ok")]
    rows, counts = [], []
    for D in ds:
        sub = ok[ok["D"] == D]
        allr = df[(df["variant"] == variant) & (df["D"] == D)]
        counts.append(dict(variant=variant, D=D, ok=len(sub),
                           failed=int((allr["status"] == "failed").sum()),
                           missing=int((allr["status"] == "missing").sum()),
                           converged=int(sub["converged"].fillna(False).astype(bool).sum()) if len(sub) else 0))
        label = f"{D} ({D})"
        if len(sub) == 0:
            rows.append([label] + ["Not run"] * len(COLUMNS))
            continue
        rows.append([label,
                     _mean_sd(sub["expected_shd"], 2),
                     _mean_sd(sub["expected_adj_f1"], 3),
                     _mean_sd(sub["cyclic_rate"], 3),
                     _pooled_median(sub),
                     _mean_sd(sub["runtime_h"], 2) if "runtime_h" in sub else "n/a"])
    table = pd.DataFrame(rows, columns=["D (edges)"] + COLUMNS)
    return table, pd.DataFrame(counts)


def p6_trend(df: pd.DataFrame, variant: str) -> dict:
    sub = df[(df["variant"] == variant) & (df["status"] == "ok")]
    out = dict(variant=variant, n_points=len(sub), n_D=int(sub["D"].nunique()))
    if sub["D"].nunique() < 3 or len(sub) < 4:
        out.update(slope_per_node=np.nan, ci_low=np.nan, ci_high=np.nan, p_value=np.nan, note="too few points")
        return out
    fit = stats.linregress(sub["D"].astype(float), sub["cyclic_rate"].astype(float))
    half = stats.t.ppf(0.975, len(sub) - 2) * fit.stderr
    out.update(slope_per_node=fit.slope, ci_low=fit.slope - half, ci_high=fit.slope + half,
               p_value=fit.pvalue, note="regression of per-run cyclic rate on D; CI > 0 supports P6")
    return out


def table_png(table: pd.DataFrame, title: str, path: str):
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(12.5, 0.55 * (len(table) + 1.6)))
    ax.axis("off")
    tbl = ax.table(cellText=table.values, colLabels=table.columns, cellLoc="center", loc="center")
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(11)
    tbl.scale(1, 1.7)
    tbl.auto_set_column_width(col=list(range(len(table.columns))))
    for (r, c), cell in tbl.get_celld().items():
        cell.set_edgecolor("#bbbbbb")
        if r == 0:
            cell.set_facecolor("#2f4b7c")
            cell.set_text_props(color="white", weight="bold")
        else:
            cell.set_facecolor("#f3f6fb" if r % 2 else "white")
            if table.iloc[r - 1, c] == "Not run":
                cell.set_text_props(color="#999999", style="italic")
    ax.set_title(title, fontsize=13, weight="bold", pad=10)
    fig.savefig(path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def plot_vs_D(df: pd.DataFrame, path: str):
    import matplotlib.pyplot as plt
    ok = df[df["status"] == "ok"]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    for ax, col, ylabel in ((axes[0], "cyclic_rate", "cyclic-sample rate"),
                            (axes[1], "expected_shd", "expected SHD")):
        for variant, label, style in (("deci_g", "DECI-G (main)", "o-"), ("deci_s", "DECI-S (validation)", "s--")):
            g = ok[ok["variant"] == variant].groupby("D")[col]
            if len(g) == 0:
                continue
            mean, sd = g.mean(), g.std(ddof=1).fillna(0.0)
            ax.plot(mean.index, mean.values, style, label=label)
            ax.fill_between(mean.index, (mean - sd).clip(lower=0), mean + sd, alpha=0.15)
        ax.set_xlabel("graph size D (nodes; D edges)")
        ax.set_ylabel(ylabel)
        ax.grid(alpha=0.3)
        ax.legend()
    axes[0].set_title("P6: cyclic samples vs D")
    axes[1].set_title("E2: structural error vs D")
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default="results/E2_lambda5")
    parser.add_argument("--out", default="results/E2_lambda5/summary")
    parser.add_argument("--g-ds", type=int, nargs="+", default=G_DS_DEFAULT, help="rows of Table 7a")
    parser.add_argument("--s-ds", type=int, nargs="+", default=S_DS_DEFAULT, help="rows of Table 7b")
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)
    path = os.path.join(args.results, "e2_per_run.csv")
    if not os.path.exists(path):
        raise SystemExit(f"{path} not found: run score_e2.py first")
    df = pd.read_csv(path)

    t7a, c7a = build_table(df, "deci_g", args.g_ds)
    t7b, c7b = build_table(df, "deci_s", args.s_ds)
    n_a = int(c7a["ok"].max()) if len(c7a) else 0
    n_b = int(c7b["ok"].max()) if len(c7b) else 0
    title_a = f"Table 7a – DECI-G (main arm), mean ± SD over {n_a} seeds"
    title_b = f"Table 7b – DECI-S (validation arm), {n_b} seeds"
    for name, t, title in (("table7a", t7a, title_a), ("table7b", t7b, title_b)):
        t.to_csv(os.path.join(args.out, f"{name}.csv"), index=False)
        with open(os.path.join(args.out, f"{name}.md"), "w") as f:
            f.write(f"**{title}**\n\n" + t.to_markdown(index=False) + "\n")
        table_png(t, title, os.path.join(args.out, f"{name}.png"))
    pd.concat([c7a, c7b]).to_csv(os.path.join(args.out, "table7_counts.csv"), index=False)
    trend = pd.DataFrame([p6_trend(df, "deci_g"), p6_trend(df, "deci_s")])
    trend.to_csv(os.path.join(args.out, "p6_trend.csv"), index=False)
    plot_vs_D(df, os.path.join(args.out, "e2_vs_D.png"))

    print(title_a); print(t7a.to_string(index=False))
    print("\n" + title_b); print(t7b.to_string(index=False))
    print("\nruns per cell:"); print(pd.concat([c7a, c7b]).to_string(index=False))
    print("\nP6 trend (cyclic rate per extra node):"); print(trend.round(4).to_string(index=False))
    print(f"\nfiles written to {args.out}")


if __name__ == "__main__":
    main()
