"""
score_e2.py - score every saved DECI run of E2 against the true graph (Table 7 inputs).

Usage (any Python with numpy + pandas):
    python score_e2.py --data data/E2 --results results/E2_lambda5

Reads    results/E2_lambda5/<variant>/<dataset_folder>/posterior_samples.npy   (100, D, D), adj[j, i] = 1: j -> i
         results/E2_lambda5/<variant>/<dataset_folder>/training_log.json
Writes   results/E2_lambda5/e2_per_run.csv       one row per (variant, D, seed) run found on disk

Per-run KPIs (Table 7 columns)
    expected_shd        mean SHD of the 100 sampled graphs vs the true graph (a reversal counts 1)
    expected_adj_f1     mean adjacency (skeleton) F1
    cyclic_rate         fraction of the 100 sampled graphs that are NOT DAGs (P6)
    cycle_lengths       shortest directed-cycle length of every cyclic sample (space separated);
                        the table reports the median over all cyclic samples of all seeds
    runtime_h           training wall-clock time in hours (from training_log.json)
Extra columns for the caption / diagnostics: converged, final_acyclicity_penalty, steps,
mean_edges (average edge count of a sampled graph; the true graph has D edges), posterior_mass_g0.

A run folder without posterior_samples.npy is recorded as status "missing" (or "failed" if train_deci.py
left an error.txt), never dropped silently.
"""

import argparse
import glob
import json
import os

import numpy as np
import pandas as pd

from metrics import expected_metrics, has_cycle, shortest_cycle_length

VARIANTS = ["deci_g", "deci_s"]


def score_run(folder: str, run_dir: str, variant: str) -> dict:
    cfg = json.load(open(os.path.join(folder, "config.json")))
    true = np.loadtxt(os.path.join(folder, "adj_matrix.csv"), delimiter=",", ndmin=2).astype(int)
    d = int(cfg["d"])
    row = dict(variant=variant, D=d, n_edges=int(cfg["n_edges"]), n_train=int(cfg["n_train"]),
               seed=int(cfg["seed"]), folder=os.path.basename(folder))
    sample_path = os.path.join(run_dir, "posterior_samples.npy")
    if not os.path.exists(sample_path):
        err = os.path.join(run_dir, "error.txt")
        row.update(status="failed" if os.path.exists(err) else "missing",
                   error=open(err).read().strip() if os.path.exists(err) else "no posterior_samples.npy")
        return row
    try:
        samples = (np.load(sample_path) > 0.5).astype(int)
        if samples.ndim != 3 or samples.shape[1:] != (d, d):
            raise ValueError(f"bad shape {samples.shape}, expected (S, {d}, {d})")
        m = expected_metrics(samples, true)
        lengths = [shortest_cycle_length(G) for G in samples if has_cycle(G)]
        row.update(expected_shd=m["expected_shd"], expected_adj_f1=m["expected_adj_f1"],
                   expected_orient_f1=m["expected_orient_f1"], posterior_mass_g0=m["posterior_mass_g0"],
                   cyclic_rate=m["cyclic_rate"], n_samples=m["n_samples"], n_cyclic=len(lengths),
                   cycle_lengths=" ".join(str(x) for x in lengths),
                   median_shortest_cycle=float(np.median(lengths)) if lengths else float("nan"),
                   mean_edges=float(samples.sum(axis=(1, 2)).mean()), status="ok", error="")
        log_path = os.path.join(run_dir, "training_log.json")
        if os.path.exists(log_path):
            log = json.load(open(log_path))
            for k in ("converged", "final_acyclicity_penalty", "steps", "outer_rounds", "runtime_s",
                      "prior_sparsity_lambda"):
                row[k] = log.get(k)
            if log.get("runtime_s") is not None:
                row["runtime_h"] = float(log["runtime_s"]) / 3600.0
    except Exception as exc:
        row.update(status="failed", error=f"{type(exc).__name__}: {exc}")
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/E2")
    parser.add_argument("--results", default="results/E2_lambda5")
    args = parser.parse_args()

    rows = []
    for variant in VARIANTS:
        for run_dir in sorted(glob.glob(os.path.join(args.results, variant, "*"))):
            name = os.path.basename(run_dir)
            folder = os.path.join(args.data, name)
            if not os.path.exists(os.path.join(folder, "config.json")):
                print(f"skipping {variant}/{name}: no dataset folder {folder}")
                continue
            rows.append(score_run(folder, run_dir, variant))
    if not rows:
        raise SystemExit(f"no runs found under {args.results}/{{{','.join(VARIANTS)}}}")
    df = pd.DataFrame(rows).sort_values(["variant", "D", "seed"]).reset_index(drop=True)
    out = os.path.join(args.results, "e2_per_run.csv")
    df.to_csv(out, index=False)
    print(df.groupby(["variant", "status"]).size().to_string())
    show = [c for c in ("variant", "D", "seed", "expected_shd", "expected_adj_f1", "cyclic_rate", "n_cyclic",
                        "median_shortest_cycle", "mean_edges", "converged", "runtime_h") if c in df.columns]
    print(df[show].round(3).to_string(index=False))
    print(f"-> {out}")


if __name__ == "__main__":
    main()
